<?php
require_once EDGE_CORE_ABS_PATH.'/shortcodes/accordions/accordion.php';
require_once EDGE_CORE_ABS_PATH.'/shortcodes/accordions/accordion-tab.php';
