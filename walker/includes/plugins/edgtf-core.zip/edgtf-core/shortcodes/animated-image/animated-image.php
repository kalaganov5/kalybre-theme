<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\AnimatedImage;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;

class AnimatedImage implements ShortcodeInterface{

	private $base;

	/**
	 * Animated Image constructor.
	 */
	public function __construct() {
		$this->base = 'edgtf_animated_image';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	/**
	 * Maps shortcode to Visual Composer. Hooked on vc_before_init
	 *
	 * @see edgt_core_get_animated_image_array_vc()
	 */
	public function vcMap() {

		vc_map(array(
			'name'                      => esc_html__('Edge Animated Image', 'edgtf-core'),
			'base'                      => $this->getBase(),
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'icon' 						=> 'icon-wpb-animated-image extended-custom-icon',
			'allowed_container_element' => 'vc_row',
			'params'                    => array(
				array(
					'type'			=> 'attach_image',
					'heading'		=>  esc_html__( 'Image', 'edgtf-core' ),
					'param_name'	=> 'image',
					'description' => esc_html__( 'Select image from media library', 'edgtf-core' )
				),
				array(
                    'type'        => 'textfield',
                    'heading'     =>  esc_html__( 'Title', 'edgtf-core' ),
                    'param_name'  => 'title',
                    'value'       => '',
                    'admin_label' => true
                ),
                array(
                    'type'       => 'dropdown',
                    'heading'    =>  esc_html__( 'Title Tag', 'edgtf-core' ),
                    'param_name' => 'title_tag',
                    'value'      => array(
                        ''   => '',
                        esc_html__( 'h2', 'edgtf-core' ) => 'h2',
                        esc_html__( 'h3', 'edgtf-core' ) => 'h3',
                        esc_html__( 'h4', 'edgtf-core' ) => 'h4',
                        esc_html__( 'h5', 'edgtf-core' ) => 'h5',
                        esc_html__( 'h6', 'edgtf-core' ) => 'h6',
                    ),
                    'dependency' => array('element' => 'title', 'not_empty' => true)
                ),
                array(
                    'type'        => 'textfield',
                    'heading'     =>  esc_html__( 'Link', 'edgtf-core' ),
                    'param_name'  => 'link',
                    'value'       => '',
                    'admin_label' => true
                ),
                array(
                    'type'       => 'dropdown',
                    'heading'    =>  esc_html__( 'Target', 'edgtf-core' ),
                    'param_name' => 'target',
                    'value'      => array(
                        ''      => '',
                        esc_html__( 'Same Window', 'edgtf-core' ) => '_self',
                        esc_html__( 'New Window', 'edgtf-core' ) => '_blank'
                    ),
                    'dependency' => array('element' => 'link', 'not_empty' => true),
                )
			)
		));

	}

	/**
	 * Renders shortcodes HTML
	 *
	 * @param $atts array of shortcode params
	 * @param $content string shortcode content
	 * @return string
	 */
	public function render($atts, $content = null) {

		$args = array(
			'image'			    => '',
			'title'			    => '',
			'title_tag'	 	    => 'h3',
			'link'			    => '',
			'target'		    => '_self'
		);

		$params = shortcode_atts($args, $atts);

		$tag_array = array('h2', 'h3', 'h4', 'h5', 'h6');
		$params['title_tag'] = (in_array($params['title_tag'], $tag_array)) ? $params['title_tag'] : $args['title_tag'];

        $params['target'] = !empty($params['target']) ? $params['target'] : '_self';

		$html = walker_edge_get_shortcode_module_template_part('templates/animated-image-template', 'animated-image', '', $params);

		return $html;
	}

}