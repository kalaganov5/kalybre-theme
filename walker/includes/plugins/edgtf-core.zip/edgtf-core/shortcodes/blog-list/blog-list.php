<?php

namespace WalkerEdgeNamespace\Modules\Shortcodes\BlogList;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;
/**
 * Class BlogList
 */
class BlogList implements ShortcodeInterface {
	/**
	* @var string
	*/
	private $base;
	
	function __construct() {
		$this->base = 'edgtf_blog_list';
		
		add_action('vc_before_init', array($this,'vcMap'));
	}
	
	public function getBase() {
		return $this->base;
	}
	public function vcMap() {

		vc_map( array(
			'name' => esc_html__('Edge Blog List', 'edgtf-core'),
			'base' => $this->base,
			'icon' => 'icon-wpb-blog-list extended-custom-icon',
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'allowed_container_element' => 'vc_row',
			'params' => array(
					array(
						'type' => 'dropdown',
						'holder' => 'div',
						'class' => '',
						'heading' =>  esc_html__( 'Type', 'edgtf-core' ),
						'param_name' => 'type',
						'value' => array(
                            esc_html__( 'Standard', 'edgtf-core' ) => 'standard',
							esc_html__( 'Masonry', 'edgtf-core' ) => 'masonry',
							esc_html__( 'Simple', 'edgtf-core' ) => 'simple',
						),
						'description' => '',
                        'save_always' => true
					),
					array(
						'type' => 'textfield',
						'holder' => 'div',
						'class' => '',
						'heading' =>  esc_html__( 'Number of Posts', 'edgtf-core' ),
						'param_name' => 'number_of_posts',
						'description' => ''
					),
                    array(
                        'type' => 'dropdown',
                        'holder' => 'div',
                        'class' => '',
                        'heading' =>  esc_html__( 'Number of Columns', 'edgtf-core' ),
                        'param_name' => 'number_of_columns',
                        'value' => array(
                            esc_html__( 'One', 'edgtf-core' ) => '1',
                            esc_html__( 'Two', 'edgtf-core' ) => '2',
                            esc_html__( 'Three', 'edgtf-core' ) => '3',
                            esc_html__( 'Four', 'edgtf-core' ) => '4'
                        ),
                        'description' => '',
                        'save_always' => true,
                        'dependency' => Array('element' => 'type', 'value' => array('standard', 'simple'))
                    ),
                    array(
                        'type' => 'dropdown',
                        'holder' => 'div',
                        'class' => '',
                        'heading' =>  esc_html__( 'Space Between Columns', 'edgtf-core' ),
                        'param_name' => 'space_between_columns',
                        'value' => array(
                            esc_html__( 'Small', 'edgtf-core' ) => 'small',
                            esc_html__( 'Normal', 'edgtf-core' ) => 'normal'
                        ),
                        'description' => '',
                        'save_always' => true,
                        'dependency' => Array('element' => 'type', 'value' => array('standard', 'masonry'))
                    ),
					array(
						'type' => 'dropdown',
						'holder' => 'div',
						'class' => '',
						'heading' =>  esc_html__( 'Order By', 'edgtf-core' ),
						'param_name' => 'order_by',
						'value' => array(
							esc_html__( 'Title', 'edgtf-core' ) => 'title',
							esc_html__( 'Date', 'edgtf-core' ) => 'date',
							esc_html__( 'Random', 'edgtf-core' ) => 'rand',
							esc_html__( 'Post Name', 'edgtf-core' ) => 'name'
						),
						'save_always' => true,
						'description' => ''
					),
					array(
						'type' => 'dropdown',
						'holder' => 'div',
						'class' => '',
						'heading' =>  esc_html__( 'Order', 'edgtf-core' ),
						'param_name' => 'order',
						'value' => array(
							esc_html__( 'ASC', 'edgtf-core' ) => 'ASC',
							esc_html__( 'DESC', 'edgtf-core' ) => 'DESC'
						),
						'save_always' => true,
						'description' => ''
					),
					array(
						'type' => 'textfield',
						'holder' => 'div',
						'class' => '',
						'heading' =>  esc_html__( 'Category Slug', 'edgtf-core' ),
						'param_name' => 'category',
						'description' => esc_html__( 'Leave empty for all or use comma for list', 'edgtf-core' )
					),
					array(
						'type' => 'dropdown',
						'holder' => 'div',
						'class' => '',
						'heading' =>  esc_html__( 'Image Size', 'edgtf-core' ),
						'param_name' => 'image_size',
						'value' => array(
							esc_html__( 'Original', 'edgtf-core' ) => 'original',
							esc_html__( 'Landscape', 'edgtf-core' ) => 'landscape',
							esc_html__( 'Square', 'edgtf-core' ) => 'square'
						),
						'description' => '',
						'dependency' => Array('element' => 'type', 'value' => array('masonry', 'standard')),
                        'save_always' => true
					),
					array(
						'type' => 'textfield',
						'holder' => 'div',
						'class' => '',
						'heading' =>  esc_html__( 'Text Length', 'edgtf-core' ),
						'param_name' => 'text_length',
						'description' => esc_html__( 'Number of characters', 'edgtf-core' ),
						'dependency' => Array('element' => 'type', 'value' => array('masonry', 'standard')),
					),
					array(
						'type' => 'dropdown',
						'class' => '',
						'heading' =>  esc_html__( 'Title Tag', 'edgtf-core' ),
						'param_name' => 'title_tag',
						'value' => array(
							''   => '',
							esc_html__( 'h2', 'edgtf-core' ) => 'h2',
							esc_html__( 'h3', 'edgtf-core' ) => 'h3',
							esc_html__( 'h4', 'edgtf-core' ) => 'h4',
							esc_html__( 'h5', 'edgtf-core' ) => 'h5',
							esc_html__( 'h6', 'edgtf-core' ) => 'h6',
						),
						'description' => ''
					),
                    array(
                        'type' => 'dropdown',
                        'holder' => 'div',
                        'class' => '',
                        'heading' =>  esc_html__( 'Enable Post Info Section', 'edgtf-core' ),
                        'param_name' => 'post_info_section',
                        'value' => array(
                            esc_html__( 'Yes', 'edgtf-core' ) => 'yes',
                            esc_html__( 'No', 'edgtf-core' ) => 'no'
                        ),
                        'save_always' => true,
                        'description' => '',
                        'dependency' => Array('element' => 'type', 'value' => array('standard', 'masonry')),
                    ),
                    array(
                        'type' => 'dropdown',
                        'holder' => 'div',
                        'class' => '',
                        'heading' =>  esc_html__( 'Enable Post Info Author', 'edgtf-core' ),
                        'param_name' => 'post_info_author',
                        'value' => array(
                            esc_html__( 'Yes', 'edgtf-core' ) => 'yes',
                            esc_html__( 'No', 'edgtf-core' ) => 'no'
                        ),
                        'save_always' => true,
                        'dependency' => Array('element' => 'post_info_section', 'value' => array('yes'))
                    ),
                    array(
                        'type' => 'dropdown',
                        'holder' => 'div',
                        'class' => '',
                        'heading' =>  esc_html__( 'Enable Post Info Date', 'edgtf-core' ),
                        'param_name' => 'post_info_date',
                        'value' => array(
                            esc_html__( 'Yes', 'edgtf-core' ) => 'yes',
                            esc_html__( 'No', 'edgtf-core' ) => 'no'
                        ),
                        'save_always' => true,
                        'dependency' => Array('element' => 'post_info_section', 'value' => array('yes'))
                    ),
                    array(
                        'type' => 'dropdown',
                        'holder' => 'div',
                        'class' => '',
                        'heading' =>  esc_html__( 'Enable Post Info Category', 'edgtf-core' ),
                        'param_name' => 'post_info_category',
                        'value' => array(
                            esc_html__( 'No', 'edgtf-core' ) => 'no',
                            esc_html__( 'Yes', 'edgtf-core' ) => 'yes'
                        ),
                        'save_always' => true,
                        'dependency' => Array('element' => 'post_info_section', 'value' => array('yes'))
                    ),
                    array(
                        'type' => 'dropdown',
                        'holder' => 'div',
                        'class' => '',
                        'heading' =>  esc_html__( 'Enable Post Info Comments', 'edgtf-core' ),
                        'param_name' => 'post_info_comments',
                        'value' => array(
                            esc_html__( 'Yes', 'edgtf-core' ) => 'yes',
                            esc_html__( 'No', 'edgtf-core' ) => 'no'
                        ),
                        'save_always' => true,
                        'dependency' => Array('element' => 'post_info_section', 'value' => array('yes'))
                    ),
                    array(
                        'type' => 'dropdown',
                        'holder' => 'div',
                        'class' => '',
                        'heading' =>  esc_html__( 'Enable Post Info Like', 'edgtf-core' ),
                        'param_name' => 'post_info_like',
                        'value' => array(
                            esc_html__( 'No', 'edgtf-core' ) => 'no',
                            esc_html__( 'Yes', 'edgtf-core' ) => 'yes'
                        ),
                        'save_always' => true,
                        'dependency' => Array('element' => 'post_info_section', 'value' => array('yes'))
                    ),
                    array(
                        'type' => 'dropdown',
                        'holder' => 'div',
                        'class' => '',
                        'heading' =>  esc_html__( 'Enable Post Info Share', 'edgtf-core' ),
                        'param_name' => 'post_info_share',
                        'value' => array(
                            esc_html__( 'No', 'edgtf-core' ) => 'no',
                            esc_html__( 'Yes', 'edgtf-core' ) => 'yes'
                        ),
                        'save_always' => true,
                        'dependency' => Array('element' => 'post_info_section', 'value' => array('yes'))
                    ),
					array(
						'type' => 'dropdown',
						'holder' => 'div',
						'class' => '',
						'heading' =>  esc_html__( 'Enable Read More Button', 'edgtf-core' ),
						'param_name' => 'read_more_button',
						'value' => array(
							esc_html__( 'Yes', 'edgtf-core' ) => 'yes',
							esc_html__( 'No', 'edgtf-core' ) => 'no'
						),
						'save_always' => true,
						'description' => '',
						'dependency' => Array('element' => 'type', 'value' => array('standard', 'masonry')),
					)
				)
		) );

	}
	public function render($atts, $content = null) {
		
		$default_atts = array(
			'type' => 'masonry',
            'number_of_posts' => '',
            'number_of_columns' => '',
            'space_between_columns' => 'normal',
            'image_size' => 'original',
            'order_by' => '',
            'order' => '',
            'category' => '',
            'title_tag' => 'h4',
			'text_length' => '90',
            'post_info_section' => 'yes',
			'post_info_author' => 'yes',
			'post_info_date' => 'yes',
			'post_info_category' => 'no',
			'post_info_comments' => 'yes',
			'post_info_like' => 'no',
			'post_info_share' => 'no',
			'read_more_button' => 'yes'
        );
		
		$params = shortcode_atts($default_atts, $atts);
		extract($params);
		$params['holder_classes'] = $this->getBlogHolderClasses($params);
	
		$queryArray = $this->generateBlogQueryArray($params);
		$query_result = new \WP_Query($queryArray);
		$params['query_result'] = $query_result;	
     
		
        $thumbImageSize = $this->generateImageSize($params);
		$params['thumb_image_size'] = $thumbImageSize;

		$html ='';
        $html .= walker_edge_get_shortcode_module_template_part('templates/blog-list-holder', 'blog-list', '', $params);
		return $html;	
	}

	/**
	   * Generates holder classes
	   *
	   * @param $params
	   *
	   * @return string
	*/
	private function getBlogHolderClasses($params){
		$holderClasses = '';

        $columnNumber = $this->getColumnNumberClass($params);
        $spaceClass = $this->getSpaceClass($params);
		
		if(!empty($params['type'])){
			switch($params['type']){
				case 'masonry':
					$holderClasses = 'edgtf-masonry';
				break;
                case 'standard' :
                    $holderClasses = 'edgtf-standard';
                break;
                case 'simple':
                    $holderClasses = 'edgtf-simple';
                    break;
				default: 
					$holderClasses = 'edgtf-masonry';
			}
		}

        $holderClasses .= ' '.$columnNumber;
        $holderClasses .= ' '.$spaceClass;
		
		return $holderClasses;
	}

    /**
     * Generates column classes
     *
     * @param $params
     *
     * @return string
     */
    private function getColumnNumberClass($params){

        $columnsNumber = '';
        $type = $params['type'];
        $columns = $params['number_of_columns'];

        if ($type == 'standard' || $type == 'simple') {
            switch ($columns) {
                case 1:
                    $columnsNumber = 'edgtf-one-column';
                    break;
                case 2:
                    $columnsNumber = 'edgtf-two-columns';
                    break;
                case 3:
                    $columnsNumber = 'edgtf-three-columns';
                    break;
                case 4:
                    $columnsNumber = 'edgtf-four-columns';
                    break;
                default:
                    $columnsNumber = 'edgtf-one-column';
                    break;
            }
        }
        return $columnsNumber;
    }

    /**
     * Generates space classes
     *
     * @param $params
     *
     * @return string
     */
    private function getSpaceClass($params){

        $spaceClass = '';
        $type = $params['type'];
        $columns = $params['space_between_columns'];

        if ($type === 'standard' || $type === 'masonry') {
            switch ($columns) {
                case 'small':
                    $spaceClass = 'edgtf-small-space';
                    break;
                case 'normal':
                    $spaceClass = 'edgtf-normal-space';
                    break;
                case 'large':
                    $spaceClass = 'edgtf-large-space';
                    break;
                default:
                    $spaceClass = 'edgtf-normal-space';
                    break;
            }
        }
        return $spaceClass;
    }

	/**
	   * Generates query array
	   *
	   * @param $params
	   *
	   * @return array
	*/
	public function generateBlogQueryArray($params){
		
		$queryArray = array(
			'orderby' => $params['order_by'],
			'order' => $params['order'],
			'posts_per_page' => $params['number_of_posts'],
			'category_name' => $params['category']
		);
		return $queryArray;
	}

	/**
	   * Generates image size option
	   *
	   * @param $params
	   *
	   * @return string
	*/
	private function generateImageSize($params){
		$thumbImageSize = '';
		$imageSize = $params['image_size'];
		
		if ($imageSize !== '' && $imageSize == 'landscape') {
            $thumbImageSize .= 'walker_edge_landscape';
        } else if($imageSize === 'square'){
			$thumbImageSize .= 'walker_edge_square';
		} else if ($imageSize !== '' && $imageSize == 'original') {
            $thumbImageSize .= 'full';
        }
		return $thumbImageSize;
	}
}