<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\Counter;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;
/**
 * Class Countdown
 */
class Countdown implements ShortcodeInterface {

	/**
	 * @var string
	 */
	private $base;

	public function __construct() {
		$this->base = 'edgtf_countdown';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase()
	{
		return $this->base;
	}

	/**
	 * Maps shortcode to Visual Composer. Hooked on vc_before_init
	 *
	 * @see edgt_core_get_carousel_slider_array_vc()
	 */
	public function vcMap() {

		vc_map( array(
			'name' => esc_html__('Edge Countdown', 'edgtf-core'),
			'base' => $this->getBase(),
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'admin_enqueue_css' => array(walker_edge_get_skin_uri().'/assets/css/edgtf-vc-extend.css'),
			'icon' => 'icon-wpb-countdown extended-custom-icon',
			'allowed_container_element' => 'vc_row',
			'params' => array(
                array(
                    'type' => 'dropdown',
                    'heading' =>  esc_html__( 'Skin', 'edgtf-core' ),
                    'param_name' => 'skin',
                    'value' => array(
                        esc_html__( 'Dark', 'edgtf-core' ) => '',
                        esc_html__( 'Light', 'edgtf-core' ) => 'edgtf-countdown-light',
                    ),
                    'save_always' => true
                ),
				array(
					'type' => 'dropdown',
					'heading' =>  esc_html__( 'Year', 'edgtf-core' ),
					'param_name' => 'year',
					'value' => array(
						'' => '',
						esc_html__( '2016', 'edgtf-core' ) => '2016',
						esc_html__( '2017', 'edgtf-core' ) => '2017',
						esc_html__( '2018', 'edgtf-core' ) => '2018',
						esc_html__( '2019', 'edgtf-core' ) => '2019',
						esc_html__( '2020', 'edgtf-core' ) => '2020'
					),
					'admin_label' => true,
					'save_always' => true
				),
				array(
					'type' => 'dropdown',
					'heading' =>  esc_html__( 'Month', 'edgtf-core' ),
					'param_name' => 'month',
					'value' => array(
						'' => '',
						esc_html__( 'January', 'edgtf-core' ) => '1',
						esc_html__( 'February', 'edgtf-core' ) => '2',
						esc_html__( 'March', 'edgtf-core' ) => '3',
						esc_html__( 'April', 'edgtf-core' ) => '4',
						esc_html__( 'May', 'edgtf-core' ) => '5',
						esc_html__( 'June', 'edgtf-core' ) => '6',
						esc_html__( 'July', 'edgtf-core' ) => '7',
						esc_html__( 'August', 'edgtf-core' ) => '8',
						esc_html__( 'September', 'edgtf-core' ) => '9',
						esc_html__( 'October', 'edgtf-core' ) => '10',
						esc_html__( 'November', 'edgtf-core' ) => '11',
						esc_html__( 'December', 'edgtf-core' ) => '12'
					),
					'admin_label' => true,
					'save_always' => true
				),
				array(
					'type' => 'dropdown',
					'heading' =>  esc_html__( 'Day', 'edgtf-core' ),
					'param_name' => 'day',
					'value' => array(
						'' => '',
						esc_html__( '1', 'edgtf-core' ) => '1',
						esc_html__( '2', 'edgtf-core' ) => '2',
						esc_html__( '3', 'edgtf-core' ) => '3',
						esc_html__( '4', 'edgtf-core' ) => '4',
						esc_html__( '5', 'edgtf-core' ) => '5',
						esc_html__( '6', 'edgtf-core' ) => '6',
						esc_html__( '7', 'edgtf-core' ) => '7',
						esc_html__( '8', 'edgtf-core' ) => '8',
						esc_html__( '9', 'edgtf-core' ) => '9',
						esc_html__( '10', 'edgtf-core' ) => '10',
						esc_html__( '11', 'edgtf-core' ) => '11',
						esc_html__( '12', 'edgtf-core' ) => '12',
						esc_html__( '13', 'edgtf-core' ) => '13',
						esc_html__( '14', 'edgtf-core' ) => '14',
						esc_html__( '15', 'edgtf-core' ) => '15',
						esc_html__( '16', 'edgtf-core' ) => '16',
						esc_html__( '17', 'edgtf-core' ) => '17',
						esc_html__( '18', 'edgtf-core' ) => '18',
						esc_html__( '19', 'edgtf-core' ) => '19',
						esc_html__( '20', 'edgtf-core' ) => '20',
						esc_html__( '21', 'edgtf-core' ) => '21',
						esc_html__( '22', 'edgtf-core' ) => '22',
						esc_html__( '23', 'edgtf-core' ) => '23',
						esc_html__( '24', 'edgtf-core' ) => '24',
						esc_html__( '25', 'edgtf-core' ) => '25',
						esc_html__( '26', 'edgtf-core' ) => '26',
						esc_html__( '27', 'edgtf-core' ) => '27',
						esc_html__( '28', 'edgtf-core' ) => '28',
						esc_html__( '29', 'edgtf-core' ) => '29',
						esc_html__( '30', 'edgtf-core' ) => '30',
						esc_html__( '31', 'edgtf-core' ) => '31',
					),
					'admin_label' => true,
					'save_always' => true
				),
				array(
					'type' => 'dropdown',
					'heading' =>  esc_html__( 'Hour', 'edgtf-core' ),
					'param_name' => 'hour',
					'value' => array(
						'' => '',
						esc_html__( '0', 'edgtf-core' ) => '0',
						esc_html__( '1', 'edgtf-core' ) => '1',
						esc_html__( '2', 'edgtf-core' ) => '2',
						esc_html__( '3', 'edgtf-core' ) => '3',
						esc_html__( '4', 'edgtf-core' ) => '4',
						esc_html__( '5', 'edgtf-core' ) => '5',
						esc_html__( '6', 'edgtf-core' ) => '6',
						esc_html__( '7', 'edgtf-core' ) => '7',
						esc_html__( '8', 'edgtf-core' ) => '8',
						esc_html__( '9', 'edgtf-core' ) => '9',
						esc_html__( '10', 'edgtf-core' ) => '10',
						esc_html__( '11', 'edgtf-core' ) => '11',
						esc_html__( '12', 'edgtf-core' ) => '12',
						esc_html__( '13', 'edgtf-core' ) => '13',
						esc_html__( '14', 'edgtf-core' ) => '14',
						esc_html__( '15', 'edgtf-core' ) => '15',
						esc_html__( '16', 'edgtf-core' ) => '16',
						esc_html__( '17', 'edgtf-core' ) => '17',
						esc_html__( '18', 'edgtf-core' ) => '18',
						esc_html__( '19', 'edgtf-core' ) => '19',
						esc_html__( '20', 'edgtf-core' ) => '20',
						esc_html__( '21', 'edgtf-core' ) => '21',
						esc_html__( '22', 'edgtf-core' ) => '22',
						esc_html__( '23', 'edgtf-core' ) => '23',
						esc_html__( '24', 'edgtf-core' ) => '24'
					),
					'admin_label' => true,
					'save_always' => true
				),
				array(
					'type' => 'dropdown',
					'heading' =>  esc_html__( 'Minute', 'edgtf-core' ),
					'param_name' => 'minute',
					'value' => array(
						'' => '',
						esc_html__( '0', 'edgtf-core' ) => '0',
						esc_html__( '1', 'edgtf-core' ) => '1',
						esc_html__( '2', 'edgtf-core' ) => '2',
						esc_html__( '3', 'edgtf-core' ) => '3',
						esc_html__( '4', 'edgtf-core' ) => '4',
						esc_html__( '5', 'edgtf-core' ) => '5',
						esc_html__( '6', 'edgtf-core' ) => '6',
						esc_html__( '7', 'edgtf-core' ) => '7',
						esc_html__( '8', 'edgtf-core' ) => '8',
						esc_html__( '9', 'edgtf-core' ) => '9',
						esc_html__( '10', 'edgtf-core' ) => '10',
						esc_html__( '11', 'edgtf-core' ) => '11',
						esc_html__( '12', 'edgtf-core' ) => '12',
						esc_html__( '13', 'edgtf-core' ) => '13',
						esc_html__( '14', 'edgtf-core' ) => '14',
						esc_html__( '15', 'edgtf-core' ) => '15',
						esc_html__( '16', 'edgtf-core' ) => '16',
						esc_html__( '17', 'edgtf-core' ) => '17',
						esc_html__( '18', 'edgtf-core' ) => '18',
						esc_html__( '19', 'edgtf-core' ) => '19',
						esc_html__( '20', 'edgtf-core' ) => '20',
						esc_html__( '21', 'edgtf-core' ) => '21',
						esc_html__( '22', 'edgtf-core' ) => '22',
						esc_html__( '23', 'edgtf-core' ) => '23',
						esc_html__( '24', 'edgtf-core' ) => '24',
						esc_html__( '25', 'edgtf-core' ) => '25',
						esc_html__( '26', 'edgtf-core' ) => '26',
						esc_html__( '27', 'edgtf-core' ) => '27',
						esc_html__( '28', 'edgtf-core' ) => '28',
						esc_html__( '29', 'edgtf-core' ) => '29',
						esc_html__( '30', 'edgtf-core' ) => '30',
						esc_html__( '31', 'edgtf-core' ) => '31',
						esc_html__( '32', 'edgtf-core' ) => '32',
						esc_html__( '33', 'edgtf-core' ) => '33',
						esc_html__( '34', 'edgtf-core' ) => '34',
						esc_html__( '35', 'edgtf-core' ) => '35',
						esc_html__( '36', 'edgtf-core' ) => '36',
						esc_html__( '37', 'edgtf-core' ) => '37',
						esc_html__( '38', 'edgtf-core' ) => '38',
						esc_html__( '39', 'edgtf-core' ) => '39',
						esc_html__( '40', 'edgtf-core' ) => '40',
						esc_html__( '41', 'edgtf-core' ) => '41',
						esc_html__( '42', 'edgtf-core' ) => '42',
						esc_html__( '43', 'edgtf-core' ) => '43',
						esc_html__( '44', 'edgtf-core' ) => '44',
						esc_html__( '45', 'edgtf-core' ) => '45',
						esc_html__( '46', 'edgtf-core' ) => '46',
						esc_html__( '47', 'edgtf-core' ) => '47',
						esc_html__( '48', 'edgtf-core' ) => '48',
						esc_html__( '49', 'edgtf-core' ) => '49',
						esc_html__( '50', 'edgtf-core' ) => '50',
						esc_html__( '51', 'edgtf-core' ) => '51',
						esc_html__( '52', 'edgtf-core' ) => '52',
						esc_html__( '53', 'edgtf-core' ) => '53',
						esc_html__( '54', 'edgtf-core' ) => '54',
						esc_html__( '55', 'edgtf-core' ) => '55',
						esc_html__( '56', 'edgtf-core' ) => '56',
						esc_html__( '57', 'edgtf-core' ) => '57',
						esc_html__( '58', 'edgtf-core' ) => '58',
						esc_html__( '59', 'edgtf-core' ) => '59',
						esc_html__( '60', 'edgtf-core' ) => '60',
					),
					'admin_label' => true,
					'save_always' => true
				),
				array(
					'type' => 'textfield',
					'heading' =>  esc_html__( 'Month Label', 'edgtf-core' ),
					'param_name' => 'month_label',
					'description' => ''
				),
				array(
					'type' => 'textfield',
					'heading' =>  esc_html__( 'Day Label', 'edgtf-core' ),
					'param_name' => 'day_label',
					'description' => ''
				),
				array(
					'type' => 'textfield',
					'heading' =>  esc_html__( 'Hour Label', 'edgtf-core' ),
					'param_name' => 'hour_label',
					'description' => ''
				),
				array(
					'type' => 'textfield',
					'heading' =>  esc_html__( 'Minute Label', 'edgtf-core' ),
					'param_name' => 'minute_label',
					'description' => ''
				),
				array(
					'type' => 'textfield',
					'heading' =>  esc_html__( 'Second Label', 'edgtf-core' ),
					'param_name' => 'second_label',
					'description' => ''
				),
				array(
					'type' => 'textfield',
					'heading' =>  esc_html__( 'Digit Font Size (px)', 'edgtf-core' ),
					'param_name' => 'digit_font_size',
					'description' => '',
					'group' =>  esc_html__( 'Design Options', 'edgtf-core' )
				),
				array(
					'type' => 'textfield',
					'heading' =>  esc_html__( 'Label Font Size (px)', 'edgtf-core' ),
					'param_name' => 'label_font_size',
					'description' => '',
					'group' =>  esc_html__( 'Design Options', 'edgtf-core' )
				)
			)
		) );

	}

	/**
	 * Renders shortcodes HTML
	 *
	 * @param $atts array of shortcode params
	 * @param $content string shortcode content
	 * @return string
	 */
	public function render($atts, $content = null) {

		$args = array(
			'skin' => '',
			'year' => '',
			'month' => '',
			'day' => '',
			'hour' => '',
			'minute' => '',
			'month_label' => esc_html__( 'Months', 'edgtf-core' ),
			'day_label' => esc_html__( 'Days', 'edgtf-core' ),
			'hour_label' => esc_html__( 'Hours', 'edgtf-core' ),
			'minute_label' => esc_html__( 'Minutes', 'edgtf-core' ),
			'second_label' => esc_html__( 'Seconds', 'edgtf-core' ),
			'digit_font_size' => '',
			'label_font_size' => ''
		);

		$params = shortcode_atts($args, $atts);

		$params['id'] = mt_rand(1000, 9999);
		$params['holder_classes'] = $this->getHolderClasses($params);

		//Get HTML from template
		$html = walker_edge_get_shortcode_module_template_part('templates/countdown-template', 'countdown', '', $params);

		return $html;

	}

    /**
     * Return Classes for Countdown
     *
     * @param $params
     * @return string
     */
    private function getHolderClasses($params) {
        return $params['skin'] != '' ? $params['skin'] : '';
    }
}