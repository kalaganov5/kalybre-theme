<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\Counter;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;
/**
 * Class Counter
 */
class Counter implements ShortcodeInterface {

	/**
	 * @var string
	 */
	private $base;

	public function __construct() {
		$this->base = 'edgtf_counter';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	/**
	 * Maps shortcode to Visual Composer. Hooked on vc_before_init
	 *
	 * @see edgt_core_get_carousel_slider_array_vc()
	 */
	public function vcMap() {

		vc_map( array(
			'name' => esc_html__('Edge Counter', 'edgtf-core'),
			'base' => $this->getBase(),
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'admin_enqueue_css' => array(walker_edge_get_skin_uri().'/assets/css/edgtf-vc-extend.css'),
			'icon' => 'icon-wpb-counter extended-custom-icon',
			'allowed_container_element' => 'vc_row',
			'params' => array(
				array(
					'type' => 'dropdown',
					'admin_label' => true,
					'heading' =>  esc_html__( 'Type', 'edgtf-core' ),
					'param_name' => 'type',
					'value' => array(
						esc_html__( 'Zero Counter', 'edgtf-core' ) => 'zero',
						esc_html__( 'Random Counter', 'edgtf-core' ) => 'random'
					),
					'save_always' => true,
					'description' => ''
				),
				array(
					'type' => 'dropdown',
					'heading' =>  esc_html__( 'Position', 'edgtf-core' ),
					'param_name' => 'position',
					'value' => array(
						esc_html__( 'Left', 'edgtf-core' ) => 'left',
						esc_html__( 'Right', 'edgtf-core' ) => 'right',
						esc_html__( 'Center', 'edgtf-core' ) => 'center'
					),
					'save_always' => true,
					'description' => ''
				),
				array(
					'type' => 'textfield',
					'admin_label' => true,
					'heading' =>  esc_html__( 'Digit', 'edgtf-core' ),
					'param_name' => 'digit',
					'description' => ''
				),
				array(
					'type' => 'textfield',
					'heading' =>  esc_html__( 'Digit Font Size (px)', 'edgtf-core' ),
					'param_name' => 'font_size',
					'description' => '',
					'group' =>  esc_html__( 'Design Options', 'edgtf-core' ),
				),
                array(
					'type' => 'colorpicker',
                    'admin_label' => true,
                    'heading' =>  esc_html__( 'Digit color', 'edgtf-core' ),
                    'param_name' => 'color',
                    'description' => '',
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
				array(
					'type' => 'textfield',
					'heading' =>  esc_html__( 'Title', 'edgtf-core' ),
					'param_name' => 'title',
					'admin_label' => true,
					'description' => ''
				),
				array(
					'type' => 'dropdown',
					'heading' =>  esc_html__( 'Title Tag', 'edgtf-core' ),
					'param_name' => 'title_tag',
					'value' => array(
						''   => '',
						esc_html__( 'h2', 'edgtf-core' ) => 'h2',
						esc_html__( 'h3', 'edgtf-core' ) => 'h3',
						esc_html__( 'h4', 'edgtf-core' ) => 'h4',
						esc_html__( 'h5', 'edgtf-core' ) => 'h5',
						esc_html__( 'h6', 'edgtf-core' ) => 'h6',
					),
					'description' => ''
				),
                array(
                    'type' => 'colorpicker',
                    'admin_label' => true,
                    'heading' =>  esc_html__( 'Title color', 'edgtf-core' ),
                    'param_name' => 'title_color',
                    'description' => '',
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
				array(
					'type' => 'textfield',
					'heading' =>  esc_html__( 'Text', 'edgtf-core' ),
					'param_name' => 'text',
					'admin_label' => true,
					'description' => ''
				),
                array(
                    'type' => 'colorpicker',
                    'admin_label' => true,
                    'heading' =>  esc_html__( 'Text color', 'edgtf-core' ),
                    'param_name' => 'text_color',
                    'description' => '',
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
				array(
					'type' => 'textfield',
					'heading' =>  esc_html__( 'Padding Bottom(px)', 'edgtf-core' ),
					'param_name' => 'padding_bottom',
					'description' => '',
					'group' =>  esc_html__( 'Design Options', 'edgtf-core' ),
				),
			)
		) );

	}

	/**
	 * Renders shortcodes HTML
	 *
	 * @param $atts array of shortcode params
	 * @param $content string shortcode content
	 * @return string
	 */
	public function render($atts, $content = null) {

		$args = array(
			'type' => '',
			'position' => '',
			'digit' => '',
			'underline_digit' => '',
			'title' => '',
			'title_tag' => 'h4',
			'title_color' => '',
			'font_size' => '',
			'color' => '',
			'text' => '',
			'text_color' => '',
			'padding_bottom' => '',

		);

		$params = shortcode_atts($args, $atts);

		//get correct heading value. If provided heading isn't valid get the default one
		$headings_array = array('h2', 'h3', 'h4', 'h5', 'h6');
		$params['title_tag'] = (in_array($params['title_tag'], $headings_array)) ? $params['title_tag'] : $args['title_tag'];

		$params['counter_holder_styles'] = $this->getCounterHolderStyle($params);
		$params['counter_styles'] = $this->getCounterStyle($params);
		$params['counter_title_styles'] = $this->getCounterTitleStyle($params);
		$params['counter_text_styles'] = $this->getCounterTextStyle($params);

		//Get HTML from template
		$html = walker_edge_get_shortcode_module_template_part('templates/counter-template', 'counter', '', $params);

		return $html;

	}

	/**
	 * Return Counter holder styles
	 *
	 * @param $params
	 * @return string
	 */
	private function getCounterHolderStyle($params) {
		$counterHolderStyle = array();

		if ($params['padding_bottom'] !== '') {

			$counterHolderStyle[] = 'padding-bottom: ' . $params['padding_bottom'] . 'px';

		}

		return implode(';', $counterHolderStyle);
	}

	/**
	 * Return Counter styles
	 *
	 * @param $params
	 * @return string
	 */
	private function getCounterStyle($params) {
		$counterStyle = array();

		if ($params['font_size'] !== '') {
			$counterStyle[] = 'font-size: ' . $params['font_size'] . 'px';
		}

        if ($params['color'] !== '') {
            $counterStyle[] = 'color: ' . $params['color'];
        }

		return implode(';', $counterStyle);
	}

    private function getCounterTitleStyle($params) {
        $counterTitleStyle = array();

        if ($params['title_color'] !== '') {
            $counterTitleStyle[] = 'color: ' . $params['title_color'];
        }

        return implode(';', $counterTitleStyle);
    }

    private function getCounterTextStyle($params) {
        $counterTextStyle = array();

        if ($params['text_color'] !== '') {
            $counterTextStyle[] = 'color: ' . $params['text_color'];
        }

        return implode(';', $counterTextStyle);
    }

}