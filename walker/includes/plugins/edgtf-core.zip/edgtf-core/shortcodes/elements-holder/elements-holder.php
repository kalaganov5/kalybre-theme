<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\ElementsHolder;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;

class ElementsHolder implements ShortcodeInterface{
	private $base;
	function __construct() {
		$this->base = 'edgtf_elements_holder';
		add_action('vc_before_init', array($this, 'vcMap'));
	}
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		vc_map( array(
			'name' => esc_html__('Edge Elements Holder', 'edgtf-core'),
			'base' => $this->base,
			'icon' => 'icon-wpb-elements-holder extended-custom-icon',
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'as_parent' => array('only' => 'edgtf_elements_holder_item'),
			'js_view' => 'VcColumnView',
			'params' => array(
				array(
					'type' => 'colorpicker',
					'class' => '',
					'heading' =>  esc_html__( 'Background Color', 'edgtf-core' ),
					'param_name' => 'background_color',
					'value' => '',
					'description' => ''
				),
				array(
					'type' => 'dropdown',
					'class' => '',
					'heading' =>  esc_html__( 'Columns', 'edgtf-core' ),
					'admin_label' => true,
					'param_name' => 'number_of_columns',
					'value' => array(
						esc_html__( '1 Column', 'edgtf-core' ) => 'one-column',
						esc_html__( '2 Columns', 'edgtf-core' ) => 'two-columns',
						esc_html__( '3 Columns', 'edgtf-core' ) => 'three-columns',
						esc_html__( '4 Columns', 'edgtf-core' ) => 'four-columns',
						esc_html__( '5 Columns', 'edgtf-core' ) => 'five-columns',
						esc_html__( '6 Columns', 'edgtf-core' ) => 'six-columns'
					),
					'description' => ''
				),
				array(
					'type' => 'checkbox',
					'class' => '',
					'heading' =>  esc_html__( 'Items Float Left', 'edgtf-core' ),
					'param_name' => 'items_float_left',
					'value' => array(esc_html__( 'Make Items Float Left?', 'edgtf-core' ) => 'yes'),
					'description' => ''
				),
				array(
					'type' => 'dropdown',
					'class' => '',
					'group' =>  esc_html__( 'Width & Responsiveness', 'edgtf-core' ),
					'heading' =>  esc_html__( 'Switch to One Column', 'edgtf-core' ),
					'param_name' => 'switch_to_one_column',
					'value' => array(
						esc_html__( 'Default', 'edgtf-core' ) => '',
						esc_html__( 'Below 1280px', 'edgtf-core' ) => '1280',
						esc_html__( 'Below 1024px', 'edgtf-core' ) => '1024',
						esc_html__( 'Below 768px', 'edgtf-core' ) => '768',
						esc_html__( 'Below 600px', 'edgtf-core' ) => '600',
						esc_html__( 'Below 480px', 'edgtf-core' ) => '480',
						esc_html__( 'Never', 'edgtf-core' ) => 'never'
					),
					'description' => esc_html__( 'Choose on which stage item will be in one column', 'edgtf-core' )
				),
				array(
					'type' => 'dropdown',
					'class' => '',
					'group' =>  esc_html__( 'Width & Responsiveness', 'edgtf-core' ),
					'heading' =>  esc_html__( 'Choose Alignment In Responsive Mode', 'edgtf-core' ),
					'param_name' => 'alignment_one_column',
					'value' => array(
						esc_html__( 'Default', 'edgtf-core' ) => '',
						esc_html__( 'Left', 'edgtf-core' ) => 'left',
						esc_html__( 'Center', 'edgtf-core' ) => 'center',
						esc_html__( 'Right', 'edgtf-core' ) => 'right'
					),
					'description' => esc_html__( 'Alignment When Items are in One Column', 'edgtf-core' )
				)
			)
		));
	}

	public function render($atts, $content = null) {
	
		$args = array(
			'number_of_columns' 		=> '',
			'switch_to_one_column'		=> '',
			'alignment_one_column' 		=> '',
			'items_float_left' 			=> '',
			'background_color' 			=> ''
		);
		$params = shortcode_atts($args, $atts);
		extract($params);

		$html						= '';

		$elements_holder_classes = array();
		$elements_holder_classes[] = 'edgtf-elements-holder';
		$elements_holder_style = '';

		if($number_of_columns != ''){
			$elements_holder_classes[] .= 'edgtf-'.$number_of_columns ;
		}

		if($switch_to_one_column != ''){
			$elements_holder_classes[] = 'edgtf-responsive-mode-' . $switch_to_one_column ;
		} else {
			$elements_holder_classes[] = 'edgtf-responsive-mode-768' ;
		}

		if($alignment_one_column != ''){
			$elements_holder_classes[] = 'edgtf-one-column-alignment-' . $alignment_one_column ;
		}

		if($items_float_left !== ''){
			$elements_holder_classes[] = 'edgtf-elements-items-float';
		}

		if($background_color != ''){
			$elements_holder_style .= 'background-color:'. $background_color . ';';
		}

		$elements_holder_class = implode(' ', $elements_holder_classes);

		$html .= '<div ' . walker_edge_get_class_attribute($elements_holder_class) . ' ' . walker_edge_get_inline_attr($elements_holder_style, 'style'). '>';
			$html .= do_shortcode($content);
		$html .= '</div>';

		return $html;

	}

}
