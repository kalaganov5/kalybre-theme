<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\FrameSliderContentItem;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;

class FrameSliderContentItem implements ShortcodeInterface {
	private $base;
	function __construct() {
		$this->base = 'edgtf_frame_slider_content_item';
		add_action('vc_before_init', array($this, 'vcMap'));
	}
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		vc_map( array(
			'name' => esc_html__('Edge Slide Content Item', 'edgtf-core'),
			'base' => $this->base,
			'icon' => 'icon-wpb-frame-slider-content-item extended-custom-icon',
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'as_child' => array('only' => 'edgtf_frame_slider_right_panel'),
			'params' => array(
				//General
				array(
				    'type'        => 'textfield',
				    'heading'     =>  esc_html__( 'Title', 'edgtf-core' ),
				    'param_name'  => 'title',
				    'value'       => '',
				    'admin_label' => true
				),
				array(
				    'type'       => 'textarea',
				    'heading'    =>  esc_html__( 'Description', 'edgtf-core' ),
				    'param_name' => 'description'
				),
				array(
				    'type'        => 'textfield',
				    'heading'     =>  esc_html__( 'Link', 'edgtf-core' ),
				    'param_name'  => 'link',
				    'value'       => '',
				    'admin_label' => true
				),
				array(
				    'type'        => 'textfield',
				    'heading'     =>  esc_html__( 'Link Text', 'edgtf-core' ),
				    'param_name'  => 'link_text',
				    'description' => '',
				    'dependency'  => array('element' => 'link', 'not_empty' => true)
				),
				array(
				    'type'       => 'dropdown',
				    'heading'    =>  esc_html__( 'Target', 'edgtf-core' ),
				    'param_name' => 'target',
				    'value'      => array(
				        esc_html__( 'Same Window', 'edgtf-core' ) => '_self',
				        esc_html__( 'New Window', 'edgtf-core' ) => '_blank'
				    ),
				    'dependency' => array('element' => 'link', 'not_empty' => true),
				),
				// Design Options
				array(
				    'type'       => 'dropdown',
				    'heading'    =>  esc_html__( 'Text Align', 'edgtf-core' ),
				    'param_name' => 'text_align',
				    'value'      => array(
				        esc_html__( 'Left', 'edgtf-core' ) => 'left',
				        esc_html__( 'Center', 'edgtf-core' ) => 'center',
				        esc_html__( 'Right', 'edgtf-core' ) => 'right'
				    ),
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
				),
				array(
				    'type'        => 'textfield',
				    'heading'     =>  esc_html__( 'Content Padding (%)', 'edgtf-core' ),
				    'param_name'  => 'content_padding',
				    'description' => esc_html__( 'Please insert padding in format (top right bottom left). Default value is 5% 5% 5% 5%', 'edgtf-core' ),
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
				),
				array(
				    'type'        => 'colorpicker',
				    'heading'     =>  esc_html__( 'Title Color', 'edgtf-core' ),
				    'param_name'  => 'title_color',
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' ),
				    'dependency' => array('element' => 'title', 'not_empty' => true)
				),
				array(
				    'type'       => 'dropdown',
				    'heading'    =>  esc_html__( 'Title Tag', 'edgtf-core' ),
				    'param_name' => 'title_tag',
				    'value'      => array(
				        esc_html__( 'h2', 'edgtf-core' ) => 'h2',
				        esc_html__( 'h3', 'edgtf-core' ) => 'h3',
				        esc_html__( 'h4', 'edgtf-core' ) => 'h4',
				        esc_html__( 'h5', 'edgtf-core' ) => 'h5',
				        esc_html__( 'h6', 'edgtf-core' ) => 'h6',
				    ),
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' ),
				    'dependency' => array('element' => 'title', 'not_empty' => true)
				),
				array(
				    'type'        => 'colorpicker',
				    'heading'     =>  esc_html__( 'Description Color', 'edgtf-core' ),
				    'param_name'  => 'description_color',
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' ),
				    'dependency' => array('element' => 'description', 'not_empty' => true)
				),
				array(
				    'type'        => 'dropdown',
				    'heading'     =>  esc_html__( 'Button Type', 'edgtf-core' ),
				    'param_name'  => 'button_type',
				    'value'       => array(
				        esc_html__( 'Solid', 'edgtf-core' ) => 'solid',
				        esc_html__( 'Simple', 'edgtf-core' ) => 'simple',
				        esc_html__( 'Outline', 'edgtf-core' ) => 'outline',
				    ),
				    'save_always' => true,
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
				),
				array(
				    'type'        => 'dropdown',
				    'heading'     =>  esc_html__( 'Button Size', 'edgtf-core' ),
				    'param_name'  => 'button_size',
				    'value'       => array(
				        esc_html__( 'Default', 'edgtf-core' ) => '',
				        esc_html__( 'Small', 'edgtf-core' ) => 'small',
				        esc_html__( 'Medium', 'edgtf-core' ) => 'medium',
				        esc_html__( 'Large', 'edgtf-core' ) => 'large',
				        esc_html__( 'Huge', 'edgtf-core' ) => 'huge'
				    ),
				    'save_always' => true,
				    'dependency'  => array('element' => 'button_type', 'value' => array('solid', 'outline')),
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
				),
				array(
				    'type'        => 'dropdown',
				    'heading'     =>  esc_html__( 'Enable Button Animate Text', 'edgtf-core' ),
				    'param_name'  => 'enable_button_animate_text',
				    'value'       => array(
				        esc_html__( 'No', 'edgtf-core' ) => 'no',
				        esc_html__( 'Yes', 'edgtf-core' ) => 'yes'
				    ),
				    'save_always' => true,
				    'dependency'  => array('element' => 'button_type', 'value' => array('solid')),
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
				),
				array(
				    'type'        => 'colorpicker',
				    'heading'     =>  esc_html__( 'Button Color', 'edgtf-core' ),
				    'param_name'  => 'button_color',
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
				),
				array(
				    'type'        => 'colorpicker',
				    'heading'     =>  esc_html__( 'Button Hover Color', 'edgtf-core' ),
				    'param_name'  => 'button_hover_color',
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
				),
				array(
				    'type'        => 'colorpicker',
				    'heading'     =>  esc_html__( 'Button Background Color', 'edgtf-core' ),
				    'param_name'  => 'button_background_color',
				    'dependency'  => array('element' => 'button_type', 'value' => array('solid')),
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
				),
				array(
				    'type'        => 'colorpicker',
				    'heading'     =>  esc_html__( 'Button Hover Background Color', 'edgtf-core' ),
				    'param_name'  => 'button_hover_background_color',
				    'dependency'  => array('element' => 'button_type', 'value' => array('solid', 'outline')),
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
				),
				array(
				    'type'        => 'colorpicker',
				    'heading'     =>  esc_html__( 'Button Border Color', 'edgtf-core' ),
				    'param_name'  => 'button_border_color',
				    'dependency'  => array('element' => 'button_type', 'value' => array('solid', 'outline')),
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
				),
				array(
				    'type'        => 'colorpicker',
				    'heading'     =>  esc_html__( 'Button Hover Border Color', 'edgtf-core' ),
				    'param_name'  => 'button_hover_border_color',
				    'dependency'  => array('element' => 'button_type', 'value' => array('solid', 'outline')),
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
				),
				array(
				    'type'        => 'textfield',
				    'heading'     =>  esc_html__( 'Button Margin', 'edgtf-core' ),
				    'param_name'  => 'button_margin',
				    'description' => esc_html__( 'Insert margin in format: 0px 0px 1px 0px', 'edgtf-core' ),
				    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
				),

			)
		));
	}

	public function render($atts, $content = null) {
	
		$args = array(
			// General
			'title'			                => '',
			'description'                   => '',
			'link'			                => '',
			'link_text' => esc_html__( 'READ MORE', 'edgtf-core' ),
			'target'		                => '_self',
			// Design Options
			'text_align'                    => 'left',
			'content_padding'               => '',
			'title_tag'	 	                => 'h2',
			'title_color'                   =>  '',
			'description_color'             => '',
			'button_type'                   => 'solid',
			'button_size'                   => 'large',
			'enable_button_animate_text'    => 'no',
			'button_color'                  => '',
			'button_hover_color'            => '',
			'button_background_color'       => '',
			'button_hover_background_color' => '',
			'button_border_color'           => '',
			'button_hover_border_color'     => '',
			'button_margin'                 => '',
		);
		$params = shortcode_atts($args, $atts);
		extract($params);

        $params['main_content_styles'] = $this->getMainContentStyles($params);
        $params['title_styles'] = $this->getTitleStyles($params);
        $params['description_styles'] = $this->getDescriptionStyles($params);
        $params['button_parameters'] = $this->getButtonParameters($params);


		$html = walker_edge_get_shortcode_module_template_part('templates/frame-slider-content-item', 'frame-slider', '', $params);

		return $html;

	}

	/**
	 * Returns array of main content styles
	 *
	 * @param $params
	 *
	 * @return array
	 */
	private function getMainContentStyles($params) {
	    $styles = array();

	    if(!empty($params['text_align'])) {
	        $styles[] = 'text-align: '.$params['text_align'];
	    }

	    if(!empty($params['content_padding'])) {
	        $styles[] = 'padding: '.$params['content_padding'];
		}
	}

	/**
	 * Returns array of title styles
	 *
	 * @param $params
	 *
	 * @return array
	 */
	private function getTitleStyles($params) {
	    $styles = array();

	    if(!empty($params['title_color'])) {
	        $styles[] = 'color: '.$params['title_color'];
	    }

	    return $styles;
	}

	/**
	 * Returns array of description styles
	 *
	 * @param $params
	 *
	 * @return array
	 */
	private function getDescriptionStyles($params) {
	    $styles = array();

	    if(!empty($params['description_color'])) {
	        $styles[] = 'color: '.$params['description_color'];
	    }

	    return $styles;
	}

	/**
	 * Returns button params array
	 *
	 * @param $params
	 * @return array
	 */
	private function getButtonParameters($params) {
	    $button_params_array = array();

	    if(!empty($params['button_type'])) {
	        $button_params_array['type'] = $params['button_type'];
	    }

	    if(!empty($params['button_size'])) {
	        $button_params_array['size'] = $params['button_size'];
	    }

	    if(!empty($params['enable_button_animate_text'])) {
	        $button_params_array['enable_animate_text'] = $params['enable_button_animate_text'];
	    }

	    if(!empty($params['link'])) {
	        $button_params_array['link'] = $params['link'];
	    }

	    if(!empty($params['link_text'])) {
	        $button_params_array['text'] = $params['link_text'];
	    }

	    if(!empty($params['target'])) {
	        $button_params_array['target'] = $params['target'];
	    }

	    if(!empty($params['button_color'])) {
	        $button_params_array['color'] = $params['button_color'];
	    }

	    if(!empty($params['button_background_color'])) {
	        $button_params_array['background_color'] = $params['button_background_color'];
	    }

	    if(!empty($params['button_border_color'])) {
	        $button_params_array['border_color'] = $params['button_border_color'];
	    }

	    if(!empty($params['button_hover_color'])) {
	        $button_params_array['hover_color'] = $params['button_hover_color'];
	    }

	    if(!empty($params['button_hover_background_color'])) {
	        $button_params_array['hover_background_color'] = $params['button_hover_background_color'];
	    }

	    if(!empty($params['button_hover_border_color'])) {
	        $button_params_array['hover_border_color'] = $params['button_hover_border_color'];
	    }

	    if(!empty($params['button_margin'])) {
	        $button_params_array['margin'] = $params['button_margin'];
	    }

	    return $button_params_array;
	}

}
