<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\FrameSliderImage;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;

class FrameSliderImage implements ShortcodeInterface {
	private $base;
	function __construct() {
		$this->base = 'edgtf_frame_slider_image';
		add_action('vc_before_init', array($this, 'vcMap'));
	}
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		vc_map( array(
			'name' => esc_html__('Edge Slide Image', 'edgtf-core'),
			'base' => $this->base,
			'icon' => 'icon-wpb-frame-slider-image extended-custom-icon',
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'as_child' => array('only' => 'edgtf_frame_slider_left_panel'),
			'params' => array(
				array(
					'type'			=> 'attach_image',
					'heading'		=>  esc_html__( 'Image', 'edgtf-core' ),
					'param_name'	=> 'image',
					'description' => esc_html__( 'Select image from media library', 'edgtf-core' )
				),
				array(
					'type'			=> 'textfield',
					'heading'		=>  esc_html__( 'Link', 'edgtf-core' ),
					'param_name'	=> 'link',
					'description' => esc_html__( 'Enter an external URL to link to.', 'edgtf-core' )
				),
				array(
				    'type'       => 'dropdown',
				    'heading'    =>  esc_html__( 'Target', 'edgtf-core' ),
				    'param_name' => 'target',
				    'value'      => array(
				        ''      => '',
				        esc_html__( 'Self', 'edgtf-core' ) => '_self',
				        esc_html__( 'Blank', 'edgtf-core' ) => '_blank'
				    ),
				    'dependency' => array('element' => 'link', 'not_empty' => true),
				),
			)
		));
	}

	public function render($atts, $content = null) {
	
		$args = array(
			'image'			    => '',
			'link'			    => '',
			'target'		    => '_self',
		);

		$params = shortcode_atts($args, $atts);

		$html = walker_edge_get_shortcode_module_template_part('templates/frame-slider-image', 'frame-slider', '', $params);

		return $html;

	}

}
