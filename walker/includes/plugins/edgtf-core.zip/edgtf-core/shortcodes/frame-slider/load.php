<?php
require_once EDGE_CORE_ABS_PATH.'/shortcodes/frame-slider/frame-slider.php';
require_once EDGE_CORE_ABS_PATH.'/shortcodes/frame-slider/frame-slider-left-panel.php';
require_once EDGE_CORE_ABS_PATH.'/shortcodes/frame-slider/frame-slider-right-panel.php';
require_once EDGE_CORE_ABS_PATH.'/shortcodes/frame-slider/frame-slider-content-item.php';
require_once EDGE_CORE_ABS_PATH.'/shortcodes/frame-slider/frame-slider-image.php';