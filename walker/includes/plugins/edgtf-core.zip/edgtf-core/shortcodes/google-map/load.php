<?php
require_once EDGE_CORE_ABS_PATH.'/shortcodes/google-map/google-map.php';

