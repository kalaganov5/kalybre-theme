<?php
require_once EDGE_CORE_ABS_PATH.'/shortcodes/icon-list-item/icon-list-item.php';
