<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\ImageWithText;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;

class ImageWithText implements ShortcodeInterface{

	private $base;

	/**
	 * Image With Text constructor.
	 */
	public function __construct() {
		$this->base = 'edgtf_image_with_text';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	/**
	 * Maps shortcode to Visual Composer. Hooked on vc_before_init
	 *
	 * @see edgt_core_get_image_with_text_array_vc()
	 */
	public function vcMap() {

		vc_map(array(
			'name'                      => esc_html__('Edge Image With Text', 'edgtf-core'),
			'base'                      => $this->getBase(),
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'icon' 						=> 'icon-wpb-image-with-text extended-custom-icon',
			'allowed_container_element' => 'vc_row',
			'params'                    => array(
				array(
					'type'			=> 'attach_image',
					'heading'		=>  esc_html__( 'Image', 'edgtf-core' ),
					'param_name'	=> 'image',
					'description' => esc_html__( 'Select image from media library', 'edgtf-core' )
				),
				array(
					'type'			=> 'textfield',
					'heading'		=>  esc_html__( 'Image Size', 'edgtf-core' ),
					'param_name'	=> 'image_size',
					'description' => esc_html__( 'Enter image size. Example: thumbnail, medium, large, full or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size', 'edgtf-core' )
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=>  esc_html__( 'Enable Lightbox Functionality', 'edgtf-core' ),
					'param_name'	=> 'enable_lightbox',
					'value'			=> array(
						esc_html__( 'No', 'edgtf-core' ) => 'no',
						esc_html__( 'Yes', 'edgtf-core' ) => 'yes'
					),
					'save_always'	=> true,
				),
				array(
                    'type'        => 'textfield',
                    'heading'     =>  esc_html__( 'Title', 'edgtf-core' ),
                    'param_name'  => 'title',
                    'value'       => '',
                    'admin_label' => true
                ),
                array(
                    'type'       => 'dropdown',
                    'heading'    =>  esc_html__( 'Title Tag', 'edgtf-core' ),
                    'param_name' => 'title_tag',
                    'value'      => array(
                        ''   => '',
                        esc_html__( 'h2', 'edgtf-core' ) => 'h2',
                        esc_html__( 'h3', 'edgtf-core' ) => 'h3',
                        esc_html__( 'h4', 'edgtf-core' ) => 'h4',
                        esc_html__( 'h5', 'edgtf-core' ) => 'h5',
                        esc_html__( 'h6', 'edgtf-core' ) => 'h6',
                    ),
                    'dependency' => array('element' => 'title', 'not_empty' => true)
                ),
                array(
                    'type'       => 'textarea',
                    'heading'    =>  esc_html__( 'Text', 'edgtf-core' ),
                    'param_name' => 'text'
                ),
                array(
                    'type'        => 'textfield',
                    'heading'     =>  esc_html__( 'Link', 'edgtf-core' ),
                    'param_name'  => 'link',
                    'value'       => '',
                    'admin_label' => true
                ),
                array(
                    'type'        => 'textfield',
                    'heading'     =>  esc_html__( 'Link Text', 'edgtf-core' ),
                    'param_name'  => 'link_text',
                    'description' => esc_html__( 'Default label is READ MORE', 'edgtf-core' ),
                    'dependency'  => array('element' => 'link', 'not_empty' => true)
                ),
                array(
                    'type'       => 'dropdown',
                    'heading'    =>  esc_html__( 'Target', 'edgtf-core' ),
                    'param_name' => 'target',
                    'value'      => array(
                        ''      => '',
                        esc_html__( 'Self', 'edgtf-core' ) => '_self',
                        esc_html__( 'Blank', 'edgtf-core' ) => '_blank'
                    ),
                    'dependency' => array('element' => 'link', 'not_empty' => true),
                ),
                array(
                	'type'	=> 'colorpicker',
                	'heading' =>  esc_html__( 'Background Color', 'edgtf-core' ),
                	'param_name' => 'background_color',
                	'group' =>  esc_html__( 'Design Options', 'edgtf-core' ),
                )
			)
		));

	}

	/**
	 * Renders shortcodes HTML
	 *
	 * @param $atts array of shortcode params
	 * @param $content string shortcode content
	 * @return string
	 */
	public function render($atts, $content = null) {

		$args = array(
			'image'			    => '',
			'image_size'	    => 'full',
			'enable_lightbox'   => '',
			'title'			    => '',
			'title_tag'	 	    => 'h4',
			'text'			    => '',
			'link'			    => '',
			'link_text' => esc_html__( 'READ MORE', 'edgtf-core' ),
			'target'		    => '_self',
            'background_color' =>  ''
		);

		$params = shortcode_atts($args, $atts);
		$params['image'] = $this->getImage($params);
		$params['image_size'] = $this->getImageSize($params['image_size']);
		$params['enable_lightbox'] = ($params['enable_lightbox'] == 'yes') ? true : false;
		$params['button_parameters'] = $this->getButtonParameters($params);
        $params['holder_classes']  = $this->getHolderClasses($params);

		$html = walker_edge_get_shortcode_module_template_part('templates/image-with-text', 'image-with-text', '', $params);

		return $html;
	}

	/**
	 * Return image for shortcode
	 *
	 * @param $params
	 * @return array
	 */
	private function getImage($params) {
        $image = array();

        if ($params['image'] !== '') {
            $id = $params['image'];

            $image['image_id'] = $id;
            $image_original = wp_get_attachment_image_src($id, 'full');
            $image['url'] = $image_original[0];
            $image['title'] = get_the_title($id);
        }

		return $image;
	}

	/**
	 * Return image size or custom image size array
	 *
	 * @param $image_size
	 * @return array
	 */
	private function getImageSize($image_size) {

		$image_size = trim($image_size);
		//Find digits
		preg_match_all( '/\d+/', $image_size, $matches );
		if(in_array( $image_size, array('thumbnail', 'thumb', 'medium', 'large', 'full'))) {
			return $image_size;
		} elseif(!empty($matches[0])) {
			return array(
					$matches[0][0],
					$matches[0][1]
			);
		} else {
			return 'thumbnail';
		}
	}

	private function getButtonParameters($params) {
		$button_params_array = array();

		$button_params_array['type'] = 'simple';

		if(!empty($params['link'])) {
			$button_params_array['link'] = $params['link'];
		}

		if(!empty($params['target'])) {
			$button_params_array['target'] = $params['target'];
		} else {
			$button_params_array['target'] = '_self';
		}

		if(!empty($params['link_text'])) {
			$button_params_array['text'] = $params['link_text'];
		}

		return $button_params_array;
	}


	/**
	 * Returns array of holder classes
	 *
	 * @param $params
	 *
	 * @return array
	 */
	private function getHolderClasses($params) {
	    $classes = array('edgtf-imwt-holder');

	    if(($params['enable_lightbox'] == 'yes')) {
	        $classes[] = 'edgtf-imwt-lightbox';
	    }

	    return $classes;
	}

}