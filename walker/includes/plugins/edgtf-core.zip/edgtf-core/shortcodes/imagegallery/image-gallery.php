<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\ImageGallery;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;

class ImageGallery implements ShortcodeInterface{

	private $base;

	/**
	 * Image Gallery constructor.
	 */
	public function __construct() {
		$this->base = 'edgtf_image_gallery';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	/**
	 * Maps shortcode to Visual Composer. Hooked on vc_before_init
	 *
	 * @see edgt_core_get_carousel_slider_array_vc()
	 */
	public function vcMap() {

		vc_map(array(
			'name'                      => esc_html__('Edge Image Gallery', 'edgtf-core'),
			'base'                      => $this->getBase(),
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'icon' 						=> 'icon-wpb-image-gallery extended-custom-icon',
			'allowed_container_element' => 'vc_row',
			'params'                    => array(
				array(
					'type'			=> 'attach_images',
					'heading'		=>  esc_html__( 'Images', 'edgtf-core' ),
					'param_name'	=> 'images',
					'description' => esc_html__( 'Select images from media library', 'edgtf-core' )
				),
				array(
					'type'			=> 'textfield',
					'heading'		=>  esc_html__( 'Image Size', 'edgtf-core' ),
					'param_name'	=> 'image_size',
					'description' => esc_html__( 'Enter image size. Example: thumbnail, medium, large, full or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size', 'edgtf-core' )
				),
				array(
					'type'        => 'dropdown',
					'heading'     =>  esc_html__( 'Gallery Type', 'edgtf-core' ),
					'admin_label' => true,
					'param_name'  => 'type',
					'value'       => array(
						esc_html__( 'Slider', 'edgtf-core' ) => 'slider',
						esc_html__( 'Image Grid', 'edgtf-core' ) => 'image_grid'
					),
					'description' => esc_html__( 'Select gallery type', 'edgtf-core' ),
					'save_always' => true
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=>  esc_html__( 'Slide duration', 'edgtf-core' ),
					'admin_label'	=> true,
					'param_name'	=> 'autoplay',
					'value'			=> array(
						esc_html__( '3', 'edgtf-core' ) => '3',
						esc_html__( '5', 'edgtf-core' ) => '5',
						esc_html__( '10', 'edgtf-core' ) => '10',
						esc_html__( 'Disable', 'edgtf-core' ) => 'disable'
					),
					'save_always'	=> true,
					'dependency'	=> array(
						'element'	=> 'type',
						'value'		=> array(
							'slider'
						)
					),
					'description' => esc_html__( 'Auto rotate slides each X seconds', 'edgtf-core' ),
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=>  esc_html__( 'Slide Animation', 'edgtf-core' ),
					'admin_label'	=> true,
					'param_name'	=> 'slide_animation',
					'value'			=> array(
						esc_html__( 'Slide', 'edgtf-core' ) => 'slide',
						esc_html__( 'Fade', 'edgtf-core' ) => 'fade',
						esc_html__( 'Fade Up', 'edgtf-core' ) => 'fadeUp',
						'Back Slide'=> 'backSlide',
						esc_html__( 'Go Down', 'edgtf-core' ) => 'goDown'
					),
					'save_always'	=> true,
					'dependency'	=> array(
						'element'	=> 'type',
						'value'		=> array(
							'slider'
						)
					)
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=>  esc_html__( 'Column Number', 'edgtf-core' ),
					'param_name'	=> 'column_number',
					'value'			=> array(2, 3, 4, 5),
					'save_always'	=> true,
					'dependency'	=> array(
						'element' 	=> 'type',
						'value'		=> array(
							'image_grid'
						)
					),
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=>  esc_html__( 'Open PrettyPhoto on click', 'edgtf-core' ),
					'param_name'	=> 'pretty_photo',
					'value'			=> array(
						esc_html__( 'No', 'edgtf-core' ) => 'no',
						esc_html__( 'Yes', 'edgtf-core' ) => 'yes'
					),
					'save_always'	=> true,
				),
                array(
                    "type" => "textarea",
                    "heading" =>  esc_html__( "Custom Links", 'edgtf-core' ),
                    "param_name" => "custom_links",
                    "value" => "",
                    "description" => esc_html__( "Delimit Links by comma", 'edgtf-core' ),
                    'dependency' => Array('element' => 'pretty_photo', 'value' => array('no'))
                ),
                array(
                    'type'       => 'dropdown',
                    'heading'    =>  esc_html__( 'Custom Link Target', 'edgtf-core' ),
                    'param_name' => 'custom_link_target',
                    'value'      => array(
                        esc_html__( 'Same Window', 'edgtf-core' ) => '_self',
                        esc_html__( 'New Window', 'edgtf-core' ) => '_blank'
                    ),
                    'save_always' => true,
                    'dependency' => Array('element' => 'pretty_photo', 'value' => array('no'))
                ),
				array(
					'type' => 'dropdown',
					'heading' =>  esc_html__( 'Grayscale Images', 'edgtf-core' ),
					'param_name' => 'grayscale',
					'value' => array(
						esc_html__( 'No', 'edgtf-core' ) => 'no',
						esc_html__( 'Yes', 'edgtf-core' ) => 'yes'
					),
					'save_always'	=> true,
					'dependency'	=> array(
						'element'	=> 'type',
						'value'		=> array(
							'image_grid'
						)
					)
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=>  esc_html__( 'Show Navigation Arrows', 'edgtf-core' ),
					'param_name' 	=> 'navigation',
					'value' 		=> array(
						esc_html__( 'Yes', 'edgtf-core' ) => 'yes',
						esc_html__( 'No', 'edgtf-core' ) => 'no'
					),
					'dependency' 	=> array(
						'element' => 'type',
						'value' => array(
							'slider'
						)
					),
					'save_always'	=> true
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=>  esc_html__( 'Show Pagination', 'edgtf-core' ),
					'param_name' 	=> 'pagination',
					'value' 		=> array(
						esc_html__( 'Yes', 'edgtf-core' ) => 'yes',
						esc_html__( 'No', 'edgtf-core' ) => 'no'
					),
					'save_always'	=> true,
					'dependency'	=> array(
						'element' => 'type',
						'value' => array(
							'slider'
						)
					)
				)
			)
		));

	}

	/**
	 * Renders shortcodes HTML
	 *
	 * @param $atts array of shortcode params
	 * @param $content string shortcode content
	 * @return string
	 */
	public function render($atts, $content = null) {

		$args = array(
			'images'			    => '',
			'image_size'		    => 'thumbnail',
			'type'				    => 'slider',
			'autoplay'			    => '5000',
			'slide_animation'	    => 'slide',
			'pretty_photo'		    => '',
			'custom_links'		    => '',
            'custom_link_target'    => '',
			'column_number'		    => '',
			'grayscale'			    => '',
			'navigation'		    => 'yes',
			'pagination'		    => 'yes'
		);

		$params = shortcode_atts($args, $atts);
		$params['slider_data'] = $this->getSliderData($params);
		$params['image_size'] = $this->getImageSize($params['image_size']);
		$params['images'] = $this->getGalleryImages($params);
		$params['pretty_photo'] = ($params['pretty_photo'] == 'yes') ? true : false;
		$params['columns'] = 'edgtf-gallery-columns-' . $params['column_number'];
		$params['gallery_classes'] = ($params['grayscale'] == 'yes') ? 'edgtf-grayscale' : '';

        $params['enable_links'] = false;
        if(!$params['pretty_photo']) {
            $params['links'] = $this->getGalleryLinks($params);
            if(count($params['images']) == count($params['links'])){
                $params['enable_links'] = true;
            };
        }

        $params['custom_link_target'] = !empty($params['custom_link_target']) ? $params['custom_link_target'] : '_self';

		if ($params['type'] == 'image_grid') {
			$template = 'gallery-grid';
		} elseif ($params['type'] == 'slider') {
			$template = 'gallery-slider';
		}

		$html = walker_edge_get_shortcode_module_template_part('templates/' . $template, 'imagegallery', '', $params);

		return $html;

	}

	/**
	 * Return images for gallery
	 *
	 * @param $params
	 * @return array
	 */
	private function getGalleryImages($params) {
		$image_ids = array();
		$images = array();
		$i = 0;

		if ($params['images'] !== '') {
			$image_ids = explode(',', $params['images']);
		}

		foreach ($image_ids as $id) {

			$image['image_id'] = $id;
			$image_original = wp_get_attachment_image_src($id, 'full');
			$image['url'] = $image_original[0];
			$image['title'] = get_the_title($id);

			$images[$i] = $image;
			$i++;
		}

		return $images;

	}

	/**
	 * Return image size or custom image size array
	 *
	 * @param $image_size
	 * @return array
	 */
	private function getImageSize($image_size) {

		$image_size = trim($image_size);
		//Find digits
		preg_match_all( '/\d+/', $image_size, $matches );
		if(in_array( $image_size, array('thumbnail', 'thumb', 'medium', 'large', 'full'))) {
			return $image_size;
		} elseif(!empty($matches[0])) {
			return array(
					$matches[0][0],
					$matches[0][1]
			);
		} else {
			return 'thumbnail';
		}
	}

	/**
	 * Return all configuration data for slider
	 *
	 * @param $params
	 * @return array
	 */
	private function getSliderData($params) {

		$slider_data = array();

		$slider_data['data-autoplay'] = ($params['autoplay'] !== '') ? $params['autoplay'] : '';
		$slider_data['data-animation'] = ($params['slide_animation'] !== '') ? $params['slide_animation'] : '';
		$slider_data['data-navigation'] = ($params['navigation'] !== '') ? $params['navigation'] : '';
		$slider_data['data-pagination'] = ($params['pagination'] !== '') ? $params['pagination'] : '';

		return $slider_data;

	}

    /**
     * Return links for gallery
     *
     * @param $params
     * @return array
     */
    private function getGalleryLinks($params) {

        $custom_links = array();

        if (!empty($params['custom_links'])) {
            $custom_links = array_map('trim', explode(',', $params['custom_links']));
	    }

        return $custom_links;

    }

}