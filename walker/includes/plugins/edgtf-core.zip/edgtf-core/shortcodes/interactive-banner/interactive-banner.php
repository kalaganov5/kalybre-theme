<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\InteractiveBanner;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;

class InteractiveBanner implements ShortcodeInterface{

    private $base;

    /**
     * Interactive Banner constructor.
     */
    public function __construct() {
        $this->base = 'edgtf_interactive_banner';

        add_action('vc_before_init', array($this, 'vcMap'));
    }

    /**
     * Returns base for shortcode
     * @return string
     */
    public function getBase() {
        return $this->base;
    }

    /**
     * Maps shortcode to Visual Composer. Hooked on vc_before_init
     *
     * @see edgt_core_get_image_with_text_array_vc()
     */
    public function vcMap() {

        vc_map(array(
            'name'                      => esc_html__('Edge Interactive Banner', 'edgtf-core'),
            'base'                      => $this->getBase(),
            'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
            'icon' 						=> 'icon-wpb-interactive-banner extended-custom-icon',
            'allowed_container_element' => 'vc_row',
            'params'                    => array(
                // General
                array(
                    'type'			=> 'attach_image',
                    'heading'		=>  esc_html__( 'Image', 'edgtf-core' ),
                    'param_name'	=> 'image',
                    'description' => esc_html__( 'Select image from media library', 'edgtf-core' )
                ),
                array(
                    'type'        => 'textfield',
                    'heading'     =>  esc_html__( 'Title', 'edgtf-core' ),
                    'param_name'  => 'title',
                    'value'       => '',
                    'admin_label' => true
                ),
                array(
                    'type'       => 'textarea',
                    'heading'    =>  esc_html__( 'Description', 'edgtf-core' ),
                    'param_name' => 'description'
                ),
                array(
                    'type'        => 'textfield',
                    'heading'     =>  esc_html__( 'Link', 'edgtf-core' ),
                    'param_name'  => 'link',
                    'value'       => '',
                    'admin_label' => true
                ),
                array(
                    'type'        => 'textfield',
                    'heading'     =>  esc_html__( 'Link Text', 'edgtf-core' ),
                    'param_name'  => 'link_text',
                    'description' => '',
                    'dependency'  => array('element' => 'link', 'not_empty' => true)
                ),
                array(
                    'type'       => 'dropdown',
                    'heading'    =>  esc_html__( 'Target', 'edgtf-core' ),
                    'param_name' => 'target',
                    'value'      => array(
                        esc_html__( 'Same Window', 'edgtf-core' ) => '_self',
                        esc_html__( 'New Window', 'edgtf-core' ) => '_blank'
                    ),
                    'dependency' => array('element' => 'link', 'not_empty' => true),
                ),

                // Design Options
                array(
                    'type'       => 'dropdown',
                    'heading'    =>  esc_html__( 'Text Align', 'edgtf-core' ),
                    'param_name' => 'text_align',
                    'value'      => array(
                        esc_html__( 'Left', 'edgtf-core' ) => 'left',
                        esc_html__( 'Center', 'edgtf-core' ) => 'center',
                        esc_html__( 'Right', 'edgtf-core' ) => 'right'
                    ),
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'        => 'textfield',
                    'heading'     =>  esc_html__( 'Content Padding (%)', 'edgtf-core' ),
                    'param_name'  => 'content_padding',
                    'description' => esc_html__( 'Please insert padding in format (top right bottom left). Default value is 5% 5% 5% 5%', 'edgtf-core' ),
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Title Color', 'edgtf-core' ),
                    'param_name'  => 'title_color',
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' ),
                    'dependency' => array('element' => 'title', 'not_empty' => true)
                ),
                array(
                    'type'       => 'dropdown',
                    'heading'    =>  esc_html__( 'Title Tag', 'edgtf-core' ),
                    'param_name' => 'title_tag',
                    'value'      => array(
                        esc_html__( 'h2', 'edgtf-core' ) => 'h2',
                        esc_html__( 'h3', 'edgtf-core' ) => 'h3',
                        esc_html__( 'h4', 'edgtf-core' ) => 'h4',
                        esc_html__( 'h5', 'edgtf-core' ) => 'h5',
                        esc_html__( 'h6', 'edgtf-core' ) => 'h6',
                    ),
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' ),
                    'dependency' => array('element' => 'title', 'not_empty' => true)
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Description Color', 'edgtf-core' ),
                    'param_name'  => 'description_color',
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' ),
                    'dependency' => array('element' => 'description', 'not_empty' => true)
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     =>  esc_html__( 'Button Type', 'edgtf-core' ),
                    'param_name'  => 'button_type',
                    'value'       => array(
                        esc_html__( 'Simple', 'edgtf-core' ) => 'simple',
                        esc_html__( 'Outline', 'edgtf-core' ) => 'outline',
                        esc_html__( 'Solid', 'edgtf-core' ) => 'solid',
                    ),
                    'save_always' => true,
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     =>  esc_html__( 'Button Size', 'edgtf-core' ),
                    'param_name'  => 'button_size',
                    'value'       => array(
                        esc_html__( 'Default', 'edgtf-core' ) => '',
                        esc_html__( 'Small', 'edgtf-core' ) => 'small',
                        esc_html__( 'Medium', 'edgtf-core' ) => 'medium',
                        esc_html__( 'Large', 'edgtf-core' ) => 'large',
                        esc_html__( 'Huge', 'edgtf-core' ) => 'huge'
                    ),
                    'save_always' => true,
                    'dependency'  => array('element' => 'button_type', 'value' => array('solid', 'outline')),
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     =>  esc_html__( 'Enable Button Animate Text', 'edgtf-core' ),
                    'param_name'  => 'enable_button_animate_text',
                    'value'       => array(
                        esc_html__( 'No', 'edgtf-core' ) => 'no',
                        esc_html__( 'Yes', 'edgtf-core' ) => 'yes'
                    ),
                    'save_always' => true,
                    'dependency'  => array('element' => 'button_type', 'value' => array('solid')),
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Button Color', 'edgtf-core' ),
                    'param_name'  => 'button_color',
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Button Hover Color', 'edgtf-core' ),
                    'param_name'  => 'button_hover_color',
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Button Background Color', 'edgtf-core' ),
                    'param_name'  => 'button_background_color',
                    'dependency'  => array('element' => 'button_type', 'value' => array('solid')),
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Button Hover Background Color', 'edgtf-core' ),
                    'param_name'  => 'button_hover_background_color',
                    'dependency'  => array('element' => 'button_type', 'value' => array('solid', 'outline')),
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Button Border Color', 'edgtf-core' ),
                    'param_name'  => 'button_border_color',
                    'dependency'  => array('element' => 'button_type', 'value' => array('solid', 'outline')),
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Button Hover Border Color', 'edgtf-core' ),
                    'param_name'  => 'button_hover_border_color',
                    'dependency'  => array('element' => 'button_type', 'value' => array('solid', 'outline')),
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'        => 'textfield',
                    'heading'     =>  esc_html__( 'Button Margin', 'edgtf-core' ),
                    'param_name'  => 'button_margin',
                    'description' => esc_html__( 'Insert margin in format: 0px 0px 1px 0px', 'edgtf-core' ),
                    'group'       =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),

                // Padding & Responsiveness
                array(
                    'type'        => 'dropdown',
                    'heading'     =>  esc_html__( 'Place Text Below Image', 'edgtf-core' ),
                    'param_name'  => 'place_text_below_image',
                    'value'       => array(
                        esc_html__( 'On Tablet Landscape', 'edgtf-core' ) => 'tablet-landscape',
                        esc_html__( 'On Tablet Portrait', 'edgtf-core' ) => 'tablet-portrait',
                        esc_html__( 'On Mobile Landscape', 'edgtf-core' ) => 'mobile-landscape',
                        esc_html__( 'On Mobile Portrait', 'edgtf-core' ) => 'mobile-portrait'
                    ),
                    'save_always' => true,
                    'group' =>  esc_html__( 'Padding & Responsiveness', 'edgtf-core' )
                ),
                array(
                    'type' => 'textfield',
                    'class' => '',
                    'heading' =>  esc_html__( 'Content Padding (%) on screen size between 1280px-1440px', 'edgtf-core' ),
                    'param_name' => 'content_padding_1280_1440',
                    'value' => '',
                    'description' => esc_html__( 'Please insert padding in format (top right bottom left). Default value is 5% 5% 5% 5%', 'edgtf-core' ),
                    'group' =>  esc_html__( 'Padding & Responsiveness', 'edgtf-core' )
                ),
                array(
                    'type' => 'textfield',
                    'class' => '',
                    'heading' =>  esc_html__( 'Content Padding (%) on screen size between 1024px-1280px', 'edgtf-core' ),
                    'param_name' => 'content_padding_1024_1280',
                    'value' => '',
                    'description' => esc_html__( 'Please insert padding in format (top right bottom left). Default value is 5% 5% 5% 5%', 'edgtf-core' ),
                    'group' =>  esc_html__( 'Padding & Responsiveness', 'edgtf-core' )
                ),
                array(
                    'type' => 'textfield',
                    'class' => '',
                    'heading' =>  esc_html__( 'Content Padding (%) on screen size between 768px-1024px', 'edgtf-core' ),
                    'param_name' => 'content_padding_768_1024',
                    'value' => '',
                    'description' => esc_html__( 'Please insert padding in format (top right bottom left). Default value is 5% 5% 5% 5%', 'edgtf-core' ),
                    'group' =>  esc_html__( 'Padding & Responsiveness', 'edgtf-core' )
                ),
                array(
                    'type' => 'textfield',
                    'class' => '',
                    'heading' =>  esc_html__( 'Content Padding (%) on screen size between 600px-768px', 'edgtf-core' ),
                    'param_name' => 'content_padding_600_768',
                    'value' => '',
                    'description' => esc_html__( 'Please insert padding in format (top right bottom left). Default value is 5% 5% 5% 5%', 'edgtf-core' ),
                    'group' =>  esc_html__( 'Padding & Responsiveness', 'edgtf-core' )
                )
            )
        ));

    }

    /**
     * Renders shortcodes HTML
     *
     * @param $atts array of shortcode params
     * @param $content string shortcode content
     * @return string
     */
    public function render($atts, $content = null) {

        $args = array(

            // General
            'image'			                => '',
            'title'			                => '',
            'description'                   => '',
            'link'			                => '',
            'link_text'		                => '',
            'target'		                => '_self',

            // Design Options
            'text_align'                    => 'left',
            'content_padding'               => '',
            'title_tag'	 	                => 'h2',
            'title_color'                   =>  '',
            'description_color'             => '',
            'button_type'                   => 'simple',
            'button_size'                   => '',
            'enable_button_animate_text'    => 'no',
            'button_color'                  => '',
            'button_hover_color'            => '',
            'button_background_color'       => '',
            'button_hover_background_color' => '',
            'button_border_color'           => '',
            'button_hover_border_color'     => '',
            'button_margin'                 => '',

            // Padding & Responsiveness
            'place_text_below_image'        => 'tablet-landscape',
            'content_padding_1280_1440'     => '',
            'content_padding_1024_1280'     => '',
            'content_padding_768_1024'      => '',
            'content_padding_600_768'       => ''
        );

        $params = shortcode_atts($args, $atts);

        $rand_class = 'edgtf-interactive-banner-custom-' . mt_rand(100000,1000000);

        $params['main_content_responsive_class'] = $rand_class;
        $params['main_content_responsive']       = $this->getMainContentResponsiveStyles($params);
        $params['main_content_classes']          = $this->getMainContentClasses($params);
        $params['main_content_styles']           = $this->getMainContentStyles($params);
        $params['title_styles']                  = $this->getTitleStyles($params);
        $params['description_styles']            = $this->getDescriptionStyles($params);
        $params['button_parameters']             = $this->getButtonParameters($params);

        $html = walker_edge_get_shortcode_module_template_part('templates/interactive-banner-template', 'interactive-banner', '', $params);

        return $html;

    }

    /**
     * Returns array of HTML classes for main content
     *
     * @param $params
     *
     * @return array
     */
    private function getMainContentClasses($params) {
        $classes = array(
            'edgtf-interactive-banner-info'
        );

        if(!empty($params['main_content_responsive_class'])) {
            $classes[] = $params['main_content_responsive_class'];
        }

        if(!empty($params['place_text_below_image'])) {
            $classes[] = 'edgtf-responsive-on-'.$params['place_text_below_image'];
        }

        return $classes;
    }

    /**
     * Returns array of main content styles
     *
     * @param $params
     *
     * @return array
     */
    private function getMainContentStyles($params) {
        $styles = array();

        if(!empty($params['text_align'])) {
            $styles[] = 'text-align: '.$params['text_align'];
        }

        if(!empty($params['content_padding'])) {
            $styles[] = 'padding: '.$params['content_padding'];
        }

        return $styles;
    }

    /**
     * Return Main Content Responsive styles
     *
     * @param $params
     * @return array
     */
    private function getMainContentResponsiveStyles($params) {

        $responsive_styles = array();

        if ($params['content_padding_1280_1440'] !== '') {
            $responsive_styles['content_padding_1280_1440'] = $params['content_padding_1280_1440'];
        }

        if ($params['content_padding_1024_1280'] !== '') {
            $responsive_styles['content_padding_1024_1280'] = $params['content_padding_1024_1280'];
        }

        if ($params['content_padding_768_1024'] !== '') {
            $responsive_styles['content_padding_768_1024'] = $params['content_padding_768_1024'];
        }

        if ($params['content_padding_600_768'] !== '') {
            $responsive_styles['content_padding_600_768'] = $params['content_padding_600_768'];
        }

        return $responsive_styles;
    }

    /**
     * Returns array of title styles
     *
     * @param $params
     *
     * @return array
     */
    private function getTitleStyles($params) {
        $styles = array();

        if(!empty($params['title_color'])) {
            $styles[] = 'color: '.$params['title_color'];
        }

        return $styles;
    }

    /**
     * Returns array of description styles
     *
     * @param $params
     *
     * @return array
     */
    private function getDescriptionStyles($params) {
        $styles = array();

        if(!empty($params['description_color'])) {
            $styles[] = 'color: '.$params['description_color'];
        }

        return $styles;
    }

    /**
     * Returns button params array
     *
     * @param $params
     * @return array
     */
    private function getButtonParameters($params) {
        $button_params_array = array();

        if(!empty($params['button_type'])) {
            $button_params_array['type'] = $params['button_type'];
        }

        if(!empty($params['button_size'])) {
            $button_params_array['size'] = $params['button_size'];
        }

        if(!empty($params['enable_button_animate_text'])) {
            $button_params_array['enable_animate_text'] = $params['enable_button_animate_text'];
        }

        if(!empty($params['link'])) {
            $button_params_array['link'] = $params['link'];
        }

        if(!empty($params['link_text'])) {
            $button_params_array['text'] = $params['link_text'];
        }

        if(!empty($params['target'])) {
            $button_params_array['target'] = $params['target'];
        }

        if(!empty($params['button_color'])) {
            $button_params_array['color'] = $params['button_color'];
        }

        if(!empty($params['button_background_color'])) {
            $button_params_array['background_color'] = $params['button_background_color'];
        }

        if(!empty($params['button_border_color'])) {
            $button_params_array['border_color'] = $params['button_border_color'];
        }

        if(!empty($params['button_hover_color'])) {
            $button_params_array['hover_color'] = $params['button_hover_color'];
        }

        if(!empty($params['button_hover_background_color'])) {
            $button_params_array['hover_background_color'] = $params['button_hover_background_color'];
        }

        if(!empty($params['button_hover_border_color'])) {
            $button_params_array['hover_border_color'] = $params['button_hover_border_color'];
        }

        if(!empty($params['button_margin'])) {
            $button_params_array['margin'] = $params['button_margin'];
        }

        return $button_params_array;
    }
}