<?php
require_once EDGE_CORE_ABS_PATH.'/shortcodes/parallax-sections/parallax-sections.php';
require_once EDGE_CORE_ABS_PATH.'/shortcodes/parallax-sections/parallax-section.php';
