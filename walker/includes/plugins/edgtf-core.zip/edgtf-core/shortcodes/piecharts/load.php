<?php

//Pie Chart Basic
include_once EDGE_CORE_ABS_PATH.'/shortcodes/piecharts/piechartbasic/load.php';