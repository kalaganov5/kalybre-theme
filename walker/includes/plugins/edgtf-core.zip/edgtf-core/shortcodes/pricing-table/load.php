<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/pricing-table/pricing-tables.php';
include_once EDGE_CORE_ABS_PATH.'/shortcodes/pricing-table/pricing-table.php';