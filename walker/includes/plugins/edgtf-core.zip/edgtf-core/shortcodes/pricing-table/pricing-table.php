<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\PricingTable;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;

class PricingTable implements ShortcodeInterface{
	private $base;
	function __construct() {
		$this->base = 'edgtf_pricing_table';
		add_action('vc_before_init', array($this, 'vcMap'));
	}
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		vc_map( array(
			'name' => esc_html__('Edge Pricing Table', 'edgtf-core'),
			'base' => $this->base,
			'icon' => 'icon-wpb-pricing-table extended-custom-icon',
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'allowed_container_element' => 'vc_row',
			'as_child' => array('only' => 'edgtf_pricing_tables'),
			'params' => array(
				array( // General Options
					'type' => 'dropdown',
					'admin_label' => true,
					'heading' =>  esc_html__( 'Type', 'edgtf-core' ),
					'param_name' => 'type',
					'value' => array(
						esc_html__( 'Title Above Price', 'edgtf-core' ) => 'title_above_price',
						esc_html__( 'Title Next To Price', 'edgtf-core' ) => 'title_in_price'
					),
					'save_always' => true,
					'description' => ''
				),
				array(
					'type' => 'textfield',
					'admin_label' => true,
					'heading' =>  esc_html__( 'Title', 'edgtf-core' ),
					'param_name' => 'title',
					'value' => esc_html__( 'Basic Plan', 'edgtf-core' ),
					'description' => ''
				),
				array(
					'type' => 'textfield',
					'admin_label' => true,
					'heading' =>  esc_html__( 'Price', 'edgtf-core' ),
					'param_name' => 'price',
					'description' => esc_html__( 'Default value is 100', 'edgtf-core' )
				),
				array(
					'type' => 'textfield',
					'admin_label' => true,
					'heading' =>  esc_html__( 'Currency', 'edgtf-core' ),
					'param_name' => 'currency',
					'description' => esc_html__( 'Default mark is $', 'edgtf-core' )
				),
				array(
					'type' => 'textfield',
					'admin_label' => true,
					'heading' =>  esc_html__( 'Price Period', 'edgtf-core' ),
					'param_name' => 'price_period',
					'description' => esc_html__( 'Default label is monthly', 'edgtf-core' )
				),
                array(
                    'type' => 'textfield',
                    'admin_label' => true,
                    'heading' =>  esc_html__( 'Price Description', 'edgtf-core' ),
                    'param_name' => 'price_description',
                    'description' => '',
                    'dependency' => array('element' => 'type',  'value' => 'title_above_price')
                ),
				array(
					'type' => 'dropdown',
					'admin_label' => true,
					'heading' =>  esc_html__( 'Show Button', 'edgtf-core' ),
					'param_name' => 'show_button',
					'value' => array(
						esc_html__( 'Yes', 'edgtf-core' ) => 'yes',
						esc_html__( 'No', 'edgtf-core' ) => 'no'
					),
					'save_always' => true,
					'description' => ''
				),
                array(
                    'type' => 'textfield',
                    'admin_label' => true,
                    'heading' =>  esc_html__( 'Button Text', 'edgtf-core' ),
                    'param_name' => 'button_text',
                    'dependency' => array('element' => 'show_button',  'value' => 'yes')
                ),
                array(
                    'type' => 'textfield',
                    'admin_label' => true,
                    'heading' =>  esc_html__( 'Button Link', 'edgtf-core' ),
                    'param_name' => 'link',
                    'dependency' => array('element' => 'show_button',  'value' => 'yes')
                ),
                array(
                    'type' => 'textarea_html',
                    'holder' => 'div',
                    'class' => '',
                    'heading' =>  esc_html__( 'Content', 'edgtf-core' ),
                    'param_name' => 'content',
                    'value' => '<li>content content content</li><li>content content content</li><li>content content content</li>',
                    'description' => ''
                ),
                array( // Design Options
                    'type' => 'dropdown',
                    'admin_label' => true,
                    'heading' =>  esc_html__( 'Enable Content Border', 'edgtf-core' ),
                    'param_name' => 'content_border',
                    'value' => array(
                        esc_html__( 'Yes', 'edgtf-core' ) => 'yes',
                        esc_html__( 'No', 'edgtf-core' ) => 'no'
                    ),
                    'save_always' => true,
                    'description' => '',
					'group' =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type' => 'colorpicker',
                    'admin_label' => true,
                    'heading' =>  esc_html__( 'Title Color', 'edgtf-core' ),
                    'param_name' => 'title_color',
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type' => 'colorpicker',
                    'admin_label' => true,
                    'heading' =>  esc_html__( 'Title Background Color', 'edgtf-core' ),
                    'param_name' => 'title_background_color',
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' ),
                    'dependency' => array('element' => 'type',  'value' => 'title_above_price')
                ),
                array(
                    'type'			=> 'attach_image',
                    'heading'		=>  esc_html__( 'Price Holder Background Image', 'edgtf-core' ),
                    'param_name'	=> 'header_image',
                    'description' => esc_html__( 'Select image from media library', 'edgtf-core' ),
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' ),
                    'dependency' => array('element' => 'type',  'value' => 'title_in_price')
                ),
                array(
                    'type' => 'colorpicker',
                    'heading' =>  esc_html__( 'Price Holder Text Color', 'edgtf-core' ),
                    'param_name' => 'header_text_color',
                    'description'	=> '',
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type' => 'colorpicker',
                    'admin_label' => true,
                    'heading' =>  esc_html__( 'Content Background Color', 'edgtf-core' ),
                    'param_name' => 'content_background_color',
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
				array(
					'type'        => 'dropdown',
					'heading'     =>  esc_html__( 'Button Type', 'edgtf-core' ),
					'param_name'  => 'button_type',
					'value'       => array(
						esc_html__( 'Outline', 'edgtf-core' ) => 'outline',
						esc_html__( 'Solid', 'edgtf-core' ) => 'solid',
						esc_html__( 'Simple', 'edgtf-core' ) => 'simple',
					),
					'save_always' => true,
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' ),
					'dependency' => array('element' => 'show_button',  'value' => 'yes')
				),
                array(
                    'type'        => 'dropdown',
                    'heading'     =>  esc_html__( 'Button Size', 'edgtf-core' ),
                    'param_name'  => 'button_size',
                    'value'       => array(
                        esc_html__( 'Small', 'edgtf-core' ) => 'small',
                        esc_html__( 'Medium', 'edgtf-core' ) => 'medium',
                        esc_html__( 'Large', 'edgtf-core' ) => 'large',
                        esc_html__( 'Huge', 'edgtf-core' ) => 'huge'
                    ),
                    'save_always' => true,
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' ),
                    'dependency' => array('element' => 'show_button',  'value' => 'yes')
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Button Color', 'edgtf-core' ),
                    'param_name'  => 'button_color',
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' ),
                    'dependency' => array('element' => 'show_button',  'value' => 'yes')
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Hover Button Color', 'edgtf-core' ),
                    'param_name'  => 'hover_button_color',
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' ),
                    'dependency' => array('element' => 'show_button',  'value' => 'yes')
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Button Background Color', 'edgtf-core' ),
                    'param_name'  => 'button_background_color',
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' ),
                    'dependency' => array('element' => 'show_button',  'value' => 'yes')
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Hover Button Background Color', 'edgtf-core' ),
                    'param_name'  => 'hover_button_background_color',
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' ),
                    'dependency' => array('element' => 'show_button',  'value' => 'yes')
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Button Border Color', 'edgtf-core' ),
                    'param_name'  => 'button_border_color',
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' ),
                    'dependency' => array('element' => 'show_button',  'value' => 'yes')
                ),
                array(
                    'type'        => 'colorpicker',
                    'heading'     =>  esc_html__( 'Hover Button Border Color', 'edgtf-core' ),
                    'param_name'  => 'hover_button_border_color',
                    'group' =>  esc_html__( 'Design Options', 'edgtf-core' ),
                    'dependency' => array('element' => 'show_button',  'value' => 'yes')
                )
			)
		));
	}

	public function render($atts, $content = null) {
	
		$args = array(
			'type'						    => 'title_above_price',
			'title' => esc_html__( 'Basic Plan', 'edgtf-core' ),
			'price'         			    => '100',
			'currency'      			    => '$',
			'price_period' => esc_html__( 'Monthly', 'edgtf-core' ),
            'price_description'  			=> '',
            'show_button'				    => 'yes',
            'button_text'   			    => 'button',
            'link'          			    => '',
            'content_border'                => '',
			'title_color'				    => '',
            'title_background_color'	    => '',
            'header_image'			        => '',
            'header_text_color'			    => '',
            'content_background_color'	    => '',
            'button_type'				    => '',
            'button_size'				    => '',
            'button_color'				    => '',
            'hover_button_color'			=> '',
            'button_background_color'		=> '',
            'hover_button_background_color' => '',
            'button_border_color'           => '',
            'hover_button_border_color'     => ''
        );
		$params = shortcode_atts($args, $atts);
//		extract($params);

		$params['button_size'] = !empty($params['button_size']) ? $params['button_size'] : 'medium';
		$params['button_type'] = !empty($params['button_type']) ? $params['button_type'] : 'solid';
		$params['link']   = !empty($params['link']) ? $params['link'] : '#';

        // prepare pricing table params
        $pricing_table_classes		= 'edgtf-price-table';

		if($params['type'] === 'title_above_price') {
			$pricing_table_classes .= ' edgtf-title-above-price';
		}
        else if($params['type'] === 'title_in_price') {
			$pricing_table_classes .= ' edgtf-title-in-price';
		}

        if($params['content_border'] === 'no') {
            $pricing_table_classes .= ' edgtf-price-table-no-border';
        }

		$params['pricing_table_classes'] = $pricing_table_classes;
		$params['content']= preg_replace('#^<\/p>|<p>$#', '', $content); // delete p tag before and after content
		$params['pricing_table_styles'] = $this->getPricingTableStyles($params);
		$params['pricing_title_styles'] = $this->getPricingTitleStyles($params);

        // prepare header styles
        $params['header_styles'] = $this->getHeaderStyles($params);

        //prepare button params
		$params['button_classes']      = $this->getButtonClasses($params);
		$params['button_styles']       = $this->getButtonStyles($params);
		$params['button_data']         = $this->getButtonDataAttr($params);

		// prepare template label
		$available_types = array('title_above_price', 'title_in_price');
		$template_label = (in_array($params['type'], $available_types)) ? str_replace('_', '-', $params['type']) : 'title-above-price';

		return walker_edge_get_shortcode_module_template_part("templates/pricing-table-{$template_label}-template",'pricing-table', '', $params);
	}

	/**
	 * Return pricing table styles
	 *
	 * @param $params
	 * @return array
	 */
	private function getPricingTableStyles($params) {

		$itemStyle = array();

		if ($params['content_background_color'] !== '') {
            $itemStyle[] = 'background-color: ' . $params['content_background_color'];
        }

		return implode(';', $itemStyle);
	}

	/**
	 * Return pricing table title styles
	 *
	 * @param $params
	 * @return array
	 */
	private function getPricingTitleStyles($params) {

		$itemStyle = array();

		if ($params['title_color'] !== '') {
            $itemStyle[] = 'color: ' . $params['title_color'];
        }

        if ($params['type'] === 'title_above_price' && $params['title_background_color'] !== '') {
            $itemStyle[] = 'background-color: ' . $params['title_background_color'];
        }

		return implode(';', $itemStyle);
	}

    /**
     * Return header styles
     *
     * @param $params
     * @return array
     */
    private function getHeaderStyles($params) {

        $headerStyles = array();

        if ($params['type'] === 'title_in_price' && $params['header_image'] !== '') {
            $headerStyles[] = 'border-bottom-color: transparent; background-image: url(' . wp_get_attachment_url($params['header_image']) . ')';
        }
        if ($params['header_text_color'] !== '') {
            $headerStyles[] = 'color: ' . $params['header_text_color'];
        }

        return implode(';', $headerStyles);
    }

	/**
	 * Returns array of button styles
	 *
	 * @param $params
	 *
	 * @return array
	 */
	private function getButtonStyles($params) {
		$styles = array();

		if(!empty($params['color'])) {
			$styles[] = 'color: '.$params['color'];
		}

		if(!empty($params['background_color']) && $params['type'] !== 'outline') {
			$styles[] = 'background-color: '.$params['background_color'];
		}

		if(!empty($params['border_color'])) {
			$styles[] = 'border-color: '.$params['border_color'];
		}

		if(!empty($params['font_size'])) {
			$styles[] = 'font-size: '.walker_edge_filter_px($params['font_size']).'px';
		}

		return $styles;
	}

	/**
	 *
	 * Returns array of button data attr
	 *
	 * @param $params
	 *
	 * @return array
	 */
	private function getButtonDataAttr($params) {
		$data = array();

		if(!empty($params['hover_color'])) {
			$data['data-hover-color'] = $params['hover_color'];
		}

		if(!empty($params['hover_background_color'])) {
			$data['data-hover-bg-color'] = $params['hover_background_color'];
		}

		if(!empty($params['hover_border_color'])) {
			$data['data-hover-border-color'] = $params['hover_border_color'];
		}

		return $data;
	}

	/**
	 * Returns array of HTML classes for button
	 *
	 * @param $params
	 *
	 * @return array
	 */
	private function getButtonClasses($params) {
		$buttonClasses = array(
			'edgtf-btn',
			'edgtf-btn-'.$params['button_size'],
			'edgtf-btn-'.$params['button_type']
		);

		if(!empty($params['hover_color'])) {
			$buttonClasses[] = 'edgtf-btn-custom-hover-color';
		}

		if(!empty($params['hover_background_color'])) {
			$buttonClasses[] = 'edgtf-btn-custom-hover-bg';
		}

		if(!empty($params['hover_border_color'])) {
			$buttonClasses[] = 'edgtf-btn-custom-border-hover';
		}

		return $buttonClasses;
	}
}