<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\PricingTables;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;

class PricingTables implements ShortcodeInterface{
	private $base;
	function __construct() {
		$this->base = 'edgtf_pricing_tables';
		add_action('vc_before_init', array($this, 'vcMap'));
	}
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {

		vc_map( array(
				'name' => esc_html__('Edge Pricing Tables', 'edgtf-core'),
				'base' => $this->base,
				'as_parent' => array('only' => 'edgtf_pricing_table'),
				'content_element' => true,
				'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
				'icon' => 'icon-wpb-pricing-tables extended-custom-icon',
				'show_settings_on_create' => true,
				'js_view' => 'VcColumnView',
				'params' => array(
					array(
						'type' => 'dropdown',
						'holder' => 'div',
						'class' => '',
						'heading' =>  esc_html__( 'Columns', 'edgtf-core' ),
						'param_name' => 'columns',
						'value' => array(
							esc_html__( 'Two', 'edgtf-core' ) => 'edgtf-two-columns',
							esc_html__( 'Three', 'edgtf-core' ) => 'edgtf-three-columns',
							esc_html__( 'Four', 'edgtf-core' ) => 'edgtf-four-columns',
						),
						'save_always' => true,
						'description' => ''
					),
					array(
						'type' => 'dropdown',
						'holder' => 'div',
						'class' => '',
						'heading' =>  esc_html__( 'Space Between Items', 'edgtf-core' ),
						'param_name' => 'space_between_items',
						'value' => array(
							esc_html__( 'Normal', 'edgtf-core' ) => 'edgtf-normal-space',
							esc_html__( 'Small', 'edgtf-core' ) => 'edgtf-small-space',
							esc_html__( 'Big', 'edgtf-core' ) => 'edgtf-big-space'
						),
						'save_always' => true,
						'description' => ''
					)
				)
		) );
	}

	public function render($atts, $content = null) {
		$args = array(
			'columns'         	  => 'edgtf-two-columns',
			'space_between_items' => 'edgtf-normal-space'
		);
		
		$params = shortcode_atts($args, $atts);
		extract($params);

		$holder_class = '';

		if ($columns !== '') {
			$holder_class .= ' '.$columns;
		}

		if ($space_between_items !== '') {
			$holder_class .= ' '.$space_between_items;
		}
		
		$html = '<div class="edgtf-pricing-tables clearfix '.esc_attr($holder_class).'">';
		$html .= '<div class="edgtf-pricing-tables-inner">';
		$html .= do_shortcode($content);
		$html .= '</div>';
		$html .= '</div>';

		return $html;
	}
}