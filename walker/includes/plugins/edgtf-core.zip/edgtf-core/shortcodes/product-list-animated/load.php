<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/product-list-animated/product-list-animated.php';