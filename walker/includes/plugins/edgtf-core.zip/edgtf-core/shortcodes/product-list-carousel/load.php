<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/product-list-carousel/product-list-carousel.php';