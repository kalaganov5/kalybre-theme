<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/product-list-simple/product-list-simple.php';