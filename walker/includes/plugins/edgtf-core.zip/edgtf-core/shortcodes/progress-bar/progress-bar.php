<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\ProgressBar;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;

class ProgressBar implements ShortcodeInterface{
	private $base;
	
	function __construct() {
		$this->base = 'edgtf_progress_bar';
		add_action('vc_before_init', array($this, 'vcMap'));
	}
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {

		vc_map( array(
			'name' => esc_html__('Edge Progress Bar', 'edgtf-core'),
			'base' => $this->base,
			'icon' => 'icon-wpb-progress-bar extended-custom-icon',
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'allowed_container_element' => 'vc_row',
			'params' => array(
                array(
                    'type'        => 'textfield',
                    'heading'     =>  esc_html__( 'Custom CSS class', 'edgtf-core' ),
                    'param_name'  => 'custom_class',
                    'admin_label' => true
                ),
				array(
					'type' => 'textfield',
					'admin_label' => true,
					'heading' =>  esc_html__( 'Title', 'edgtf-core' ),
					'param_name' => 'title',
					'description' => ''
				),
				array(
					'type' => 'dropdown',
					'admin_label' => true,
					'heading' =>  esc_html__( 'Title Tag', 'edgtf-core' ),
					'param_name' => 'title_tag',
					'value' => array(
						''   => '',
						esc_html__( 'h2', 'edgtf-core' ) => 'h2',
						esc_html__( 'h3', 'edgtf-core' ) => 'h3',
						esc_html__( 'h4', 'edgtf-core' ) => 'h4',
						esc_html__( 'h5', 'edgtf-core' ) => 'h5',
						esc_html__( 'h6', 'edgtf-core' ) => 'h6',
						esc_html__( 'paragraph', 'edgtf-core' ) => 'p'
					),
					'description' => ''
				),
                array(
                    'type' => 'colorpicker',
                    'admin_label' => true,
                    'heading' =>  esc_html__( 'Active Color', 'edgtf-core' ),
                    'param_name' => 'color_active',
                    'description' => ''
                ),
                array(
                    'type' => 'colorpicker',
                    'admin_label' => true,
                    'heading' =>  esc_html__( 'Inactive Color', 'edgtf-core' ),
                    'param_name' => 'color_inactive',
                    'description' => ''
                ),
				array(
					'type' => 'textfield',
					'admin_label' => true,
					'heading' =>  esc_html__( 'Percentage', 'edgtf-core' ),
					'param_name' => 'percent',
					'description' => ''
				)
			)
		) );
	}

	public function render($atts, $content = null) {
		$args = array(
            'custom_class' => '',
            'title' => '',
            'title_tag' => 'h5',
            'color_active' => '',
            'color_inactive' => '',
            'percent' => '100',
        );
		$params = shortcode_atts($args, $atts);
		
		//Extract params for use in method
		extract($params);
		$headings_array = array('h2', 'h3', 'h4', 'h5', 'h6');

        //get correct heading value. If provided heading isn't valid get the default one
        $title_tag = (in_array($title_tag, $headings_array)) ? $title_tag : $args['title_tag'];
		
        $params['holder_classes']  = $this->getHolderClasses($params);
        $params['active_bar_style']  = $this->getActiveColor($params);
        $params['inactive_bar_style']  = $this->getInactiveColor($params);

        //init variables
		$html = walker_edge_get_shortcode_module_template_part('templates/progress-bar-template', 'progress-bar', '', $params);
		
        return $html;
	}

    /**
     * Returns array of holder classes
     *
     * @param $params
     *
     * @return array
     */
    private function getHolderClasses($params) {
        $classes = array('edgtf-progress-bar');

        if(!empty($params['custom_class'])) {
            $classes[] = $params['custom_class'];
        }

        return $classes;
    }

    /**
     * Return active color for active bar
     *
     * @param $params
     *
     * @return array
     */
    private function getActiveColor($params) {
        $styles = array();

        if(!empty($params['color_active'])) {
            $styles[] = 'background-color: '.$params['color_active'];
        }

        return $styles;
    }

    /**
     * Return active color for inactive bar
     *
     * @param $params
     *
     * @return array
     */
    private function getInactiveColor($params) {
        $styles = array();

        if(!empty($params['color_inactive'])) {
            $styles[] = 'background-color: '.$params['color_inactive'];
        }

        return $styles;
    }

}