<?php
require_once EDGE_CORE_ABS_PATH.'/shortcodes/showcase-carousel/showcase-carousel.php';