<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\SocialButton;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;

class SocialButton implements ShortcodeInterface {

	private $base;

	/**
	 * Social Button constructor.
	 */
	public function __construct() {
		$this->base = 'edgtf_social_button';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	/**
	 * Maps shortcode to Visual Composer. Hooked on vc_before_init
	 *
	 * @see edgt_core_get_social_button_array_vc()
	 */
	public function vcMap() {

		vc_map(array(
			'name' => esc_html__('Edge Social Button', 'edgtf-core'),
			'base' => $this->getBase(),
			'icon' => 'icon-wpb-social-button extended-custom-icon',
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'allowed_container_element' => 'vc_row',
			'params' => array(
				array(	// General
                    'type'        	=> 'textfield',
                    'heading'     	=>  esc_html__( 'Title', 'edgtf-core' ),
                    'param_name'  	=> 'title',
                    'value'       	=> '',
                    'admin_label' 	=> true
                ),
                array(
                    'type'        	=> 'textfield',
                    'heading'     	=>  esc_html__( 'Link', 'edgtf-core' ),
                    'param_name'  	=> 'link',
                    'value'       	=> ''
                ),
                array(
                    'type'       => 'dropdown',
                    'heading'    =>  esc_html__( 'Target', 'edgtf-core' ),
                    'param_name' => 'target',
                    'value'      => array(
                        esc_html__( 'Same Window', 'edgtf-core' ) => '_self',
                        esc_html__( 'New Window', 'edgtf-core' ) => '_blank'
                    ),
					'save_always' => true
                ),
				array(
                    'type'        	=> 'textfield',
                    'heading'     	=>  esc_html__( 'Width', 'edgtf-core' ),
                    'param_name'  	=> 'width',
                    'value'       	=> ''
                ),
                array(
					'type'			=> 'textfield',
					'class' 		=> '',
					'heading' 		=>  esc_html__( 'Padding', 'edgtf-core' ),
					'param_name'	=> 'padding',
					'value' 		=> '',
					'description' => esc_html__( 'Please insert padding in format (top right bottom left). Example 0px 10px 0px 10px. Also you use percentage mark.', 'edgtf-core' )
				),
				array(
					'type'			=> 'textfield',
					'class' 		=> '',
					'heading' 		=>  esc_html__( 'Margin', 'edgtf-core' ),
					'param_name'	=> 'margin',
					'value' 		=> '',
					'description' => esc_html__( 'Please insert margin in format (top right bottom left). Example 0px 10px 0px 10px. Also you use percentage mark.', 'edgtf-core' )
				),
				array(	// Typography
                    "type" 			=> "textfield",
					"heading" 		=>  esc_html__( "Font Size (px)", 'edgtf-core' ),
					"param_name" 	=> "font_size",
					"value" 		=> "",
                    'dependency'	=> array('element' => 'title', 'not_empty' => true),
                    'group'       	=>  esc_html__( 'Typography', 'edgtf-core' )
                ),
				array(
                    "type" 			=> "dropdown",
					"heading" 		=>  esc_html__( "Font Weight", 'edgtf-core' ),
					"param_name" 	=> "font_weight",
					"value" 		=> array_flip(walker_edge_get_font_weight_array(true)),
					"save_always" 	=> true,
                    'dependency'	=> array('element' => 'title', 'not_empty' => true),
                    'group'       	=>  esc_html__( 'Typography', 'edgtf-core' )
                ),
                array(
                    "type" 			=> "dropdown",
					"heading" 		=>  esc_html__( "Font Style", 'edgtf-core' ),
					"param_name" 	=> "font_style",
					"value" 		=> walker_edge_get_font_style_array(),
					"save_always" 	=> true,
                    'dependency'	=> array('element' => 'title', 'not_empty' => true),
                    'group'       	=>  esc_html__( 'Typography', 'edgtf-core' )
                ),
                array(
					"type" 			=> "textfield",
					"heading" 		=>  esc_html__( "Line Height (px)", 'edgtf-core' ),
					"param_name" 	=> "line_height",
					"value" 		=> "",
					'dependency'	=> array('element' => 'title', 'not_empty' => true),
                    'group'       	=>  esc_html__( 'Typography', 'edgtf-core' )
				),
				array(
					"type" 			=> "textfield",
					"heading" 		=>  esc_html__( "Letter Spacing (px)", 'edgtf-core' ),
					"param_name" 	=> "letter_spacing",
					"value" 		=> "",
					'dependency'	=> array('element' => 'title', 'not_empty' => true),
                    'group'       	=>  esc_html__( 'Typography', 'edgtf-core' )
				),
                array(	// Design
                    'type'     		=> 'colorpicker',
                    'heading'    	=>  esc_html__( 'Color', 'edgtf-core' ),
                    'param_name' 	=> 'color',
                    'dependency'	=> array('element' => 'title', 'not_empty' => true),
                    'group'       	=>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'       	=> 'colorpicker',
                    'heading'   	=>  esc_html__( 'Hover Color', 'edgtf-core' ),
                    'param_name' 	=> 'hover_color',
                    'dependency'	=> array('element' => 'title', 'not_empty' => true),
                    'group'       	=>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'       	=> 'colorpicker',
                    'heading'    	=>  esc_html__( 'Background Color', 'edgtf-core' ),
                    'param_name' 	=> 'background_color',
                    'dependency'	=> array('element' => 'title', 'not_empty' => true),
                    'group'       	=>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'       	=> 'colorpicker',
                    'heading'    	=>  esc_html__( 'Hover Background Color', 'edgtf-core' ),
                    'param_name' 	=> 'hover_background_color',
                    'dependency'	=> array('element' => 'title', 'not_empty' => true),
                    'group'       	=>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'        	=> 'textfield',
                    'heading'     	=>  esc_html__( 'Border Width (px)', 'edgtf-core' ),
                    'param_name'  	=> 'border_width',
                    'value'       	=> '',
                    'dependency'	=> array('element' => 'title', 'not_empty' => true),
                    'group'       	=>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'       	=> 'colorpicker',
                    'heading'    	=>  esc_html__( 'Border Color', 'edgtf-core' ),
                    'param_name' 	=> 'border_color',
                    'dependency'	=> array('element' => 'title', 'not_empty' => true),
                    'group'       	=>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
                array(
                    'type'       	=> 'colorpicker',
                    'heading'    	=>  esc_html__( 'Hover Border Color', 'edgtf-core' ),
                    'param_name' 	=> 'hover_border_color',
                    'dependency'	=> array('element' => 'title', 'not_empty' => true),
                    'group'       	=>  esc_html__( 'Design Options', 'edgtf-core' )
                ),
			)
		));

	}

	/**
	 * Renders shortcodes HTML
	 *
	 * @param $atts array of shortcode params
	 * @param $content string shortcode content
	 * @return string
	 */
	public function render($atts, $content = null) {
		 $args = array(
            'title'                		=> '',
            'link'                		=> '',
            'target'                	=> '_self',
            'width'                 	=> '100%',
            'padding'               	=> '',
            'margin'               		=> '',
            'font_size'                 => '',
            'font_weight'               => '',
            'font_style'               	=> '',
            'line_height'            	=> '',
            'letter_spacing'            => '',
            'color'        				=> '#333',
            'hover_color'               => '#333',
            'background_color'          => '',
            'hover_background_color'	=> '',
            'border_width'            	=> '',
            'border_color'       		=> '',
            'hover_border_color' 		=> ''
        );

		$params = shortcode_atts($args, $atts);
		$params['button_styles'] = $this->getButtonStyles($params);
		$params['button_data'] = $this->getButtonData($params);
        $params['button_span_data'] = $this->getButtonSpanData($params);
		
		$html = walker_edge_get_shortcode_module_template_part('templates/social-button-template', 'social-button', '', $params);

		return $html;
	}

	/**
     * Returns inline button styles
     *
     * @param $params
     *
     * @return string
     */
    private function getButtonStyles($params) {
        $styles = array();

        if(!empty($params['width'])) {
            $styles[] = 'width: ' . $params['width'];
        }
        if(!empty($params['padding'])) {
            $styles[] = 'padding: ' . $params['padding'];
        }
        if(!empty($params['margin'])) {
            $styles[] = 'margin: ' . $params['margin'];
        }
        if(!empty($params['font_size'])) {
            $styles[] = 'font-size: ' . walker_edge_filter_px($params['font_size']) . 'px';
        }
        if(!empty($params['font_weight']) && $params['font_weight'] !== '') {
         	$styles[] = 'font-weight: '.$params['font_weight'];
        }
        if(!empty($params['font_style'])) {
         	$styles[] = 'font-style: '.$params['font_style'];
        }
        if(!empty($params['line_height'])) {
            $styles[] = 'line-height: '.walker_edge_filter_px($params['line_height']) . 'px';
        }
        if(!empty($params['letter_spacing'])) {
            $styles[] = 'letter-spacing: '.walker_edge_filter_px($params['letter_spacing']) . 'px';
        }
        if(!empty($params['color'])) {
            $styles[] = 'color: ' . $params['color'];
        }
        if(!empty($params['background_color'])) {
         	$styles[] = 'background-color: ' . $params['background_color'];
        }
        if(!empty($params['border_width'])) {
            $styles[] = 'border-width: '.walker_edge_filter_px($params['border_width']) . 'px';
        }
        if(!empty($params['border_color'])) {
            $styles[] = 'border-color: ' . $params['border_color'];
            
            if(empty($params['border_width'])) {
            	$styles[] = 'border-width: 1px';
            }
        }

        return implode(';', $styles);
    }

    /**
     * Returns button data array for hover style
     *
     * @param $params
     *
     * @return array
     */
    private function getButtonData($params) {
        $data = array();

        if(!empty($params['hover_color'])) {
            $data['data-hover-color'] = $params['hover_color'];
        }
        if(!empty($params['color'])) {
            $data['data-color'] = $params['color'];
        }
        if(!empty($params['hover_background_color'])) {
         	$data['data-hover-background-color'] = $params['hover_background_color'];
        }
        if(!empty($params['hover_border_color'])) {
            $data['data-hover-border-color'] = $params['hover_border_color'];
        }

        return $data;
    }

    /**
     * Returns button data array for hover style
     *
     * @param $params
     *
     * @return array
     */
    private function getButtonSpanData($params) {
        $data = array();

        if(!empty($params['title'])) {
            $data['data-title'] = $params['title'];
        }

        return $data;
    }
}