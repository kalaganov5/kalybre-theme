<div class="edgtf-social-share-holder edgtf-list">
	<ul>
		<?php foreach ($networks as $net) {
			echo walker_edge_get_module_part( $net );
		} ?>
	</ul>
</div>