<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/team-carousels/team-carousels.php';
include_once EDGE_CORE_ABS_PATH.'/shortcodes/team-carousels/team-carousel.php';