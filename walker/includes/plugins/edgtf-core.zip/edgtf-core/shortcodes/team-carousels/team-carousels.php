<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\TeamCarousels;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;
/**
 * Class TeamCarousels
 */
class TeamCarousels implements ShortcodeInterface {
	/**
	 * @var string
	 */
	private $base;

	public function __construct() {
		$this->base = 'edgtf_team_carousels';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	/**
	 * Maps shortcode to Visual Composer. Hooked on vc_before_init
	 *
	 * @see edgt_core_get_carousel_slider_array_vc()
	 */
	public function vcMap()	{

		vc_map( array(
			'name' => esc_html__('Edge Team Carousel', 'edgtf-core'),
			'base' => $this->getBase(),
			'as_parent' => array('only' => 'edgtf_team_carousel'),
			'content_element' => true,
			'show_settings_on_create' => true,
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'icon' => 'icon-wpb-team-carousels extended-custom-icon',
			'js_view' => 'VcColumnView',
			'params' => array (
                array(
                    'type'        => 'textfield',
                    'heading'     =>  esc_html__( 'Custom CSS class', 'edgtf-core' ),
                    'param_name'  => 'custom_class',
                    'admin_label' => true
                ),
				array(
					'type' => 'dropdown',
					'admin-label' => true,
					'heading' =>  esc_html__( 'Number Of Visible Items', 'edgtf-core' ),
					'param_name' => 'items',
					'value' => array(
						esc_html__( 'One', 'edgtf-core' ) => '1',
						esc_html__( 'Two', 'edgtf-core' ) => '2',
						esc_html__( 'Three', 'edgtf-core' ) => '3',
						esc_html__( 'Four', 'edgtf-core' ) => '4',
						esc_html__( 'Five', 'edgtf-core' ) => '5',
						esc_html__( 'Six', 'edgtf-core' ) => '6'
					),
					'save_always' => true,
					'description' => ''
				),
				array(
					'type' => 'textfield',
					'heading' =>  esc_html__( 'Carousel Speed', 'edgtf-core' ),
					'admin_label' => true,
                    'value' => '5000',
					'param_name' => 'speed',
                    'save_always' => true,
					'description' => esc_html__( 'Default value is 5000. Value is in ms.', 'edgtf-core' )
				),
                array(
                    'type' => 'dropdown',
                    'heading' =>  esc_html__( 'Show navigation?', 'edgtf-core' ),
                    'param_name' => 'show_navigation',
                    'value' => array(
                        esc_html__( 'No', 'edgtf-core' ) => '',
                        esc_html__( 'Next/Prev', 'edgtf-core' ) => 'next-prev',
                        esc_html__( 'Paging', 'edgtf-core' ) => 'paging',
                    ),
                    'admin_label' => true,
                    'description' => ''
                )
			)
		) );
	}

	/**
	 * Renders shortcodes HTML
	 *
	 * @param $atts array of shortcode params
	 * @param $content string shortcode content
	 * @return string
	 */
	public function render($atts, $content = null) {
		$args = array(
			'custom_class' 	 => '',
			'items' 	 => '4',
			'speed'      => '5000',
			'show_navigation' => '',
		);

		$params = shortcode_atts($args, $atts);

        $team_data = $this->getTeamCarouselDataAttributes($params);
        $team_holder_class = $this->getHolderClasses($params);

		extract($params);

		$html = '';

		$html .= '<div class="edgtf-team-carousel-holder '.esc_html($team_holder_class).'">';
			$html .= '<div class="edgtf-team-carousel-inner edgtf-grid" '.walker_edge_get_inline_attrs($team_data).'>';
				$html .= do_shortcode($content);
			$html .= '</div>';

		$html .= '</div>';

		return $html;
	}

    /**
     * Return all data that team carousel needs
     *
     * @param $params
     * @return array
     */
    private function getTeamCarouselDataAttributes($params) {

        $data_attr = array();

        if(!empty($params['show_navigation'])){
            $data_attr['data-navigation'] = $params['show_navigation'];
        }
        if(!empty($params['speed'])) {
            $data_attr['data-speed'] = $params['speed'];
        }
        if(!empty($params['items'])) {
            $data_attr['data-items'] = $params['items'];
        }

        return $data_attr;
    }

    /**
     * Returns array of holder classes
     *
     * @param $params
     *
     * @return array
     */
    private function getHolderClasses($params) {
        $classes = '';

        if(!empty($params['custom_class'])) {
            $classes .= $params['custom_class'];
        }

        return $classes;
    }
}