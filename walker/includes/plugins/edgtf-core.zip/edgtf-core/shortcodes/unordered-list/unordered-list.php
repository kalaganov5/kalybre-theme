<?php
namespace WalkerEdgeNamespace\Modules\Shortcodes\UnorderedList;

use WalkerEdgeNamespace\Modules\Shortcodes\ShortcodeInterface;

/**
 * Class unordered List
 */
class UnorderedList implements ShortcodeInterface{

	private $base;

	function __construct() {
		$this->base='edgtf_unordered_list';
		
		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**\
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	public function vcMap() {

		vc_map( array(
			'name' => esc_html__('Edge List - Unordered', 'edgtf-core'),
			'base' => $this->base,
			'icon' => 'icon-wpb-unordered-list extended-custom-icon',
			'category' => esc_html__( 'by EDGE', 'edgtf-core' ),
			'allowed_container_element' => 'vc_row',
			'params' => array(
				array(
					'type' => 'dropdown',
					'admin_label' => true,
					'heading' =>  esc_html__( 'Style', 'edgtf-core' ),
					'param_name' => 'style',
					'value' => array(
						esc_html__( 'Circle', 'edgtf-core' ) => 'circle',
						esc_html__( 'Check Mark', 'edgtf-core' ) => 'check-mark',
						esc_html__( 'None', 'edgtf-core' ) => 'none'
					),
					'description' => ''
				),
				array(
					'type' => 'dropdown',
					'admin_label' => true,
					'heading' =>  esc_html__( 'Animate List', 'edgtf-core' ),
					'param_name' => 'animate',
					'value' => array(
						esc_html__( 'No', 'edgtf-core' ) => 'no',
						esc_html__( 'Yes', 'edgtf-core' ) => 'yes'
					),
					'description' => ''
				),
				array(
					'type' => 'textfield',
					'heading' =>  esc_html__( 'Padding left (px)', 'edgtf-core' ),
					'param_name' => 'padding_left',
					'value' => ''
				),
				array(
					'type' => 'textarea_html',
					'heading' =>  esc_html__( 'Content', 'edgtf-core' ),
					'param_name' => 'content',
					'value' => '<ul><li>Lorem Ipsum</li><li>Lorem Ipsum</li><li>Lorem Ipsum</li></ul>',
					'description' => ''
				)
			)
		) );
	}

	public function render($atts, $content = null) {
		$args = array(
            'style' => '',
            'animate' => '',
            'padding_left' => ''
        );
		$params = shortcode_atts($args, $atts);
		
		//Extract params for use in method
		extract($params);
		
		$list_item_classes = "";

        if ($style != '') {
			if($style == 'circle'){
				$list_item_classes .= ' edgtf-circle';
			}elseif ($style == 'check-mark') {
				$list_item_classes .= ' edgtf-check-mark';
			}
            elseif ($style == 'none') {
                $list_item_classes .= ' edgtf-without-style';
            }
        }

		if ($animate == 'yes') {
			$list_item_classes .= ' edgtf-animate-list';
		}
		
		$list_style = '';
		if($padding_left != '') {
			$list_style .= 'padding-left: ' . $padding_left .'px;';
		}
		$content = preg_replace('#^<\/p>|<p>$#', '', $content);
        $html = '<div class="edgtf-unordered-list '.$list_item_classes.'" '.  walker_edge_get_inline_style($list_style).'>'.do_shortcode($content).'</div>';
        return $html;
	}
}