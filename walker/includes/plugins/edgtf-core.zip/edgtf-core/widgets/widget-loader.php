<?php

if ( ! function_exists( 'walker_edge_register_widgets' ) ) {
	function walker_edge_register_widgets() {
		$widgets = array(
			'WalkerEdgeClassBlogListWidget',
			'WalkerEdgeClassFullScreenMenuOpener',
			'WalkerEdgeClassImageWidget',
			'WalkerEdgeClassEdgefPopupOpener',
			'WalkerEdgeClassSearchOpener',
			'WalkerEdgeClassSeparatorWidget',
			'WalkerEdgeClassSideAreaOpener',
			'WalkerEdgeClassStickySidebar',
			'WalkerEdgeClassSocialIconWidget'
		);
		
		if ( edgt_core_theme_installed() && walker_edge_is_woocommerce_installed() ) {
			$widgets[] = 'WalkerEdgeClassWoocommerceDropdownCart';
		}
		
		sort( $widgets );
		
		foreach ( $widgets as $widget ) {
			register_widget( $widget );
		}
	}
	
	add_action( 'widgets_init', 'walker_edge_register_widgets' );
}