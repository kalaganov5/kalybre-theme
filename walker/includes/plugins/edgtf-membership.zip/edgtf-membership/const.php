<?php

define('EDGE_MEMBERSHIP_VERSION', '1.2.1');
define('EDGE_MEMBERSHIP_ABS_PATH', dirname(__FILE__));
define('EDGE_MEMBERSHIP_REL_PATH', dirname(plugin_basename(__FILE__ )));