<ul class="edgtf-membership-dashboard-nav clearfix">
	<?php
	$nav_items = edgtf_membership_get_dashboard_navigation_items();
	foreach ( $nav_items as $nav_item ) { ?>
		<li>
			<a href="<?php echo esc_url( $nav_item['url'] ); ?>">
				<?php echo wp_kses_post( $nav_item['text'] ); ?>
			</a>
		</li>
	<?php } ?>
	<li>
		<a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">
			<?php esc_html_e( 'Log out', 'edgtf-membership' ); ?>
		</a>
	</li>
</ul>