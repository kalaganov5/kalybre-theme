<div class="edgtf-register-notice">
	<h5><?php echo esc_html($message); ?></h5>
	<a href="#" class="edgtf-login-action-btn" data-el="#edgtf-login-content" data-title="<?php esc_html_e('LOGIN', 'edgtf-membership'); ?>"><?php esc_html_e('LOGIN', 'edgtf-membership'); ?></a>
</div>